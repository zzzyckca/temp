"""可調參數 — 所有 magic number 集中喺呢度,方便 tune。"""

# --- 頁面 rasterize ---
RENDER_DPI = 150            # 每頁 render 成圖嘅解像度

# --- 檔名配對 ---
MATCH_THRESHOLD = 85        # 0-100,自動配對嘅最低相似度

# --- 像素 diff(捉圖表 / 圖形改動)---
PIXEL_DIFF_THRESHOLD = 30   # 0-255,灰階差要幾大先當「唔同」
PIXEL_DILATE_ITER = 3       # 將相近嘅差異點合埋做一個區域
PIXEL_MIN_AREA = 120        # 細過呢個面積嘅差異當雜訊 (px^2 @ RENDER_DPI)
PIXEL_BOX_PAD = 4           # 每個像素差異框向外擴嘅 px

# --- 標示顏色 (R, G, B) ---
COL_DELETE = (220, 38, 38)      # 被刪除嘅文字(顯示喺 A 邊)   紅
COL_INSERT = (22, 163, 74)      # 新增嘅文字(顯示喺 B 邊)     綠
COL_REPLACE = (234, 88, 12)     # 被改動嘅文字(兩邊都有)       橙
COL_PIXEL = (220, 38, 38)       # 圖表 / 圖形差異                 紅
FILL_ALPHA = 55                 # 0-255,框內半透明填色
BOX_WIDTH = 2                   # 文字框線粗幼
PIXEL_BOX_WIDTH = 3             # 圖表框線粗幼


class Settings:
    """可喺介面即時調較嘅參數(用上面嘅預設做起點)。

    比對函數(comparer.*)會收呢個 object 做 ``cfg``,所以介面改咗數值,
    下一次比對就即刻用新值,唔使改檔或者 restart。
    """

    def __init__(self):
        self.RENDER_DPI = RENDER_DPI
        self.MATCH_THRESHOLD = MATCH_THRESHOLD
        self.PIXEL_DIFF_THRESHOLD = PIXEL_DIFF_THRESHOLD
        self.PIXEL_DILATE_ITER = PIXEL_DILATE_ITER
        self.PIXEL_MIN_AREA = PIXEL_MIN_AREA
        self.PIXEL_BOX_PAD = PIXEL_BOX_PAD
        self.COL_DELETE = COL_DELETE
        self.COL_INSERT = COL_INSERT
        self.COL_REPLACE = COL_REPLACE
        self.COL_PIXEL = COL_PIXEL
        self.FILL_ALPHA = FILL_ALPHA
        self.BOX_WIDTH = BOX_WIDTH
        self.PIXEL_BOX_WIDTH = PIXEL_BOX_WIDTH
