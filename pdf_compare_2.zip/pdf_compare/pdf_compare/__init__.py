"""pdf_compare — 用 GUI 比對兩個資料夾入面 fuzzy-match 到嘅 PDF。"""
__version__ = "0.1.0"
