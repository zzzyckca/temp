"""將 A 資料夾嘅 PDF 同 B 資料夾嘅 PDF 用檔名相似度配對。

- 檔名會先正規化(去 prefix/suffix 雜訊、版本號、日期)
- 用 rapidfuzz.WRatio 計相似度(對前後綴、部分重疊都幾穩陣)
- 用匈牙利演算法(scipy)做「最優一對一配對」,避免兩個檔搶同一個對象
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
from rapidfuzz import fuzz, process

from . import config
from .scanner import PdfFile

_SEP = re.compile(r"[_\-.]+")
_NOISE = re.compile(
    r"\b("
    r"v\d+|ver\d*|rev\d*|final|draft|copy|"          # 版本 / 狀態字
    r"\d{4}[-_]?\d{2}[-_]?\d{2}|"                      # 日期 2024-01-31
    r"\d{6,8}"                                         # 純數字日期 / 流水號
    r")\b"
)
_WS = re.compile(r"\s+")


def normalize(name: str) -> str:
    """把檔名化簡,方便比對。"""
    s = name.lower()
    if s.endswith(".pdf"):
        s = s[:-4]
    s = _SEP.sub(" ", s)
    s = _NOISE.sub(" ", s)
    s = _WS.sub(" ", s).strip()
    return s or name.lower()


def similarity(a: str, b: str) -> float:
    """0-100 檔名相似度。"""
    return float(fuzz.WRatio(normalize(a), normalize(b)))


@dataclass
class MatchPair:
    a: PdfFile
    b: PdfFile
    score: float


def _score_matrix(files_a: list[PdfFile], files_b: list[PdfFile]) -> np.ndarray:
    names_a = [normalize(f.name) for f in files_a]
    names_b = [normalize(f.name) for f in files_b]
    # rapidfuzz 用 C++ 一次過計整個矩陣,快好多
    return process.cdist(
        names_a, names_b, scorer=fuzz.WRatio, dtype=np.float32, workers=-1
    )


def match_files(
    files_a: list[PdfFile],
    files_b: list[PdfFile],
    threshold: float = config.MATCH_THRESHOLD,
) -> tuple[list[MatchPair], list[PdfFile], list[PdfFile]]:
    """回傳 (已配對, A邊未配對, B邊未配對)。"""
    from scipy.optimize import linear_sum_assignment

    if not files_a or not files_b:
        return [], list(files_a), list(files_b)

    sim = _score_matrix(files_a, files_b)
    row, col = linear_sum_assignment(sim, maximize=True)

    pairs: list[MatchPair] = []
    used_a: set[int] = set()
    used_b: set[int] = set()
    for i, j in zip(row, col):
        if sim[i, j] >= threshold:
            pairs.append(MatchPair(files_a[i], files_b[j], float(sim[i, j])))
            used_a.add(int(i))
            used_b.add(int(j))

    pairs.sort(key=lambda p: p.score, reverse=True)
    unmatched_a = [f for k, f in enumerate(files_a) if k not in used_a]
    unmatched_b = [f for k, f in enumerate(files_b) if k not in used_b]
    return pairs, unmatched_a, unmatched_b


def best_candidates(
    target: PdfFile, others: list[PdfFile], k: int = 5
) -> list[tuple[PdfFile, float]]:
    """俾未配對嘅檔搵最相似嘅幾個對象(手動配對時用)。"""
    scored = [(o, similarity(target.name, o.name)) for o in others]
    scored.sort(key=lambda t: t[1], reverse=True)
    return scored[:k]
