"""PySide6 GUI: pick two folders -> auto-match -> inspect diffs pair by pair.

Layout:
  top     two folder inputs + comparison settings + "Scan & Match"
  left    matched list, unmatched A / B (manual pair / unpair)
  right   page navigation + two tabs:
            "Text / Number diff" - word-level diff, click a change to highlight it
            "Chart / Pixel diff" - pixel diff, changed image regions boxed in red
  Both sides shown side by side; zoom / pan are synced.
"""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QRectF, QTimer
from PySide6.QtGui import QColor, QImage, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QGraphicsScene,
    QGraphicsView,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from . import comparer, config
from .matcher import MatchPair, match_files, similarity
from .scanner import PdfFile, scan_pdfs


# --------------------------------------------------------------------------- #
def pil_to_qpixmap(img) -> QPixmap:
    img = img.convert("RGBA")
    data = img.tobytes("raw", "RGBA")
    qim = QImage(data, img.width, img.height, QImage.Format_RGBA8888)
    return QPixmap.fromImage(qim.copy())  # copy() so the QPixmap owns the buffer


# --------------------------------------------------------------------------- #
class ImageView(QGraphicsView):
    """Zoom / pan image view that can stay in sync with another ImageView."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._scene = QGraphicsScene(self)
        self.setScene(self._scene)
        self._item = None
        self._peer: "ImageView | None" = None
        self._syncing = False

        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setRenderHint(QPainter.SmoothPixmapTransform, True)
        self.setBackgroundBrush(QColor("#2b2b2b"))
        self.horizontalScrollBar().valueChanged.connect(self._sync)
        self.verticalScrollBar().valueChanged.connect(self._sync)

    def set_peer(self, peer: "ImageView"):
        self._peer = peer

    def set_image(self, pil_img):
        pm = pil_to_qpixmap(pil_img)
        self._scene.clear()
        self._item = self._scene.addPixmap(pm)
        self._scene.setSceneRect(QRectF(pm.rect()))
        self.fit()

    def fit(self):
        if self._item is not None:
            self.fitInView(self._item, Qt.KeepAspectRatio)

    def wheelEvent(self, e):
        if self._item is None:
            return
        factor = 1.25 if e.angleDelta().y() > 0 else 1 / 1.25
        self.scale(factor, factor)
        self._sync()

    def center_on_rect(self, x0, y0, x1, y1):
        self.centerOn((x0 + x1) / 2, (y0 + y1) / 2)

    # --- syncing ---
    def _sync(self, *_):
        if self._syncing or self._peer is None:
            return
        self._peer._apply_from(self)

    def _apply_from(self, src: "ImageView"):
        self._syncing = True
        try:
            self.setTransform(src.transform())
            self._copy_scroll(src.horizontalScrollBar(), self.horizontalScrollBar())
            self._copy_scroll(src.verticalScrollBar(), self.verticalScrollBar())
        finally:
            self._syncing = False

    @staticmethod
    def _copy_scroll(src, dst):
        srng = src.maximum() - src.minimum()
        frac = 0.0 if srng == 0 else (src.value() - src.minimum()) / srng
        drng = dst.maximum() - dst.minimum()
        dst.setValue(int(dst.minimum() + frac * drng))


# --------------------------------------------------------------------------- #
class SideBySide(QWidget):
    """A | B synced views with coloured header strips."""

    def __init__(self, label_a="A · original", label_b="B · compare"):
        super().__init__()
        self.view_a = ImageView()
        self.view_b = ImageView()
        self.view_a.set_peer(self.view_b)
        self.view_b.set_peer(self.view_a)

        split = QSplitter(Qt.Horizontal)
        split.addWidget(self._wrap(label_a, self.view_a, "#b91c1c"))
        split.addWidget(self._wrap(label_b, self.view_b, "#15803d"))
        split.setSizes([600, 600])

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(split)

    @staticmethod
    def _wrap(label, view, color):
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(2)
        lbl = QLabel(label)
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet(
            f"color:white;background:{color};padding:3px;font-weight:bold;border-radius:2px"
        )
        v.addWidget(lbl)
        v.addWidget(view)
        return box

    def set_images(self, img_a, img_b):
        self.view_a.set_image(img_a)
        self.view_b.set_image(img_b)

    def fit(self):
        self.view_a.fit()
        self.view_b.fit()


# --------------------------------------------------------------------------- #
class ScanWorker(QThread):
    done = Signal(object, object, object)   # pairs, unmatched_a, unmatched_b
    failed = Signal(str)

    def __init__(self, root_a, root_b, threshold):
        super().__init__()
        self.root_a = root_a
        self.root_b = root_b
        self.threshold = threshold

    def run(self):
        try:
            fa = scan_pdfs(self.root_a)
            fb = scan_pdfs(self.root_b)
            pairs, ua, ub = match_files(fa, fb, self.threshold)
            self.done.emit(pairs, ua, ub)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


# --------------------------------------------------------------------------- #
class MainWindow(QMainWindow):
    def __init__(self, prefill_a="", prefill_b=""):
        super().__init__()
        self.setWindowTitle("PDF Compare — Folder Diff")
        self.resize(1400, 900)

        self.pairs: list[MatchPair] = []
        self.unmatched_a: list[PdfFile] = []
        self.unmatched_b: list[PdfFile] = []
        self.current_pair: MatchPair | None = None
        self.page_idx = 0
        self.n_pages = 0
        self._page_cache: dict[int, comparer.PageResult] = {}
        self._worker: ScanWorker | None = None
        self.settings = config.Settings()

        # Debounce re-render while dragging a spinbox
        self._apply_timer = QTimer(self)
        self._apply_timer.setSingleShot(True)
        self._apply_timer.setInterval(250)
        self._apply_timer.timeout.connect(self._reapply_settings)

        self._build_ui()
        if prefill_a:
            self.le_a.setText(prefill_a)
        if prefill_b:
            self.le_b.setText(prefill_b)

    # ---- UI ----------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        root.addWidget(self._build_top_form())

        split = QSplitter(Qt.Horizontal)
        split.addWidget(self._build_left_panel())
        split.addWidget(self._build_right_panel())
        split.setSizes([340, 1060])
        split.setStretchFactor(1, 1)
        root.addWidget(split, 1)

        self.statusBar().showMessage("Pick two folders, then click 'Scan & Match'.")
        self._build_shortcuts()

    def _build_top_form(self) -> QWidget:
        w = QFrame()
        w.setFrameShape(QFrame.StyledPanel)
        v = QVBoxLayout(w)

        self.le_a = QLineEdit()
        self.le_a.setPlaceholderText("Folder A path")
        btn_a = QPushButton("Browse…")
        btn_a.clicked.connect(lambda: self._browse(self.le_a))
        row_a = QHBoxLayout()
        row_a.addWidget(QLabel("Folder A"))
        row_a.addWidget(self.le_a, 1)
        row_a.addWidget(btn_a)
        v.addLayout(row_a)

        self.le_b = QLineEdit()
        self.le_b.setPlaceholderText("Folder B path")
        btn_b = QPushButton("Browse…")
        btn_b.clicked.connect(lambda: self._browse(self.le_b))
        row_b = QHBoxLayout()
        row_b.addWidget(QLabel("Folder B"))
        row_b.addWidget(self.le_b, 1)
        row_b.addWidget(btn_b)
        v.addLayout(row_b)

        # --- Comparison settings (all adjustable live) ---
        params = QGroupBox("Comparison settings")
        pgl = QHBoxLayout(params)

        self.spin_thr = self._mk_spin(0, 100, config.MATCH_THRESHOLD, suffix=" %")
        self.spin_thr.setToolTip("Minimum filename similarity to auto-pair. "
                                 "Higher = stricter. Applies on the next 'Scan & Match'.")
        self.spin_dpi = self._mk_spin(72, 400, config.RENDER_DPI, step=6)
        self.spin_dpi.setToolTip("Page render resolution. Higher = sharper / more precise, but slower.")
        self.spin_pdiff = self._mk_spin(0, 255, config.PIXEL_DIFF_THRESHOLD)
        self.spin_pdiff.setToolTip("Pixel-diff sensitivity (grayscale delta). Lower = more sensitive.")
        self.spin_pmin = self._mk_spin(0, 20000, config.PIXEL_MIN_AREA, step=10, suffix=" px²")
        self.spin_pmin.setToolTip("Ignore image-diff regions smaller than this area (px²).")
        self.spin_dilate = self._mk_spin(0, 15, config.PIXEL_DILATE_ITER)
        self.spin_dilate.setToolTip("Merge nearby diff pixels into one region. Larger = bigger boxes.")

        for text, sp in (
            ("Name match", self.spin_thr),
            ("Render DPI", self.spin_dpi),
            ("Pixel sensitivity", self.spin_pdiff),
            ("Min region", self.spin_pmin),
            ("Region merge", self.spin_dilate),
        ):
            pgl.addWidget(QLabel(text))
            pgl.addWidget(sp)
            pgl.addSpacing(10)
        pgl.addStretch(1)

        # The four comparison params re-render the current page (debounced)
        for sp in (self.spin_dpi, self.spin_pdiff, self.spin_pmin, self.spin_dilate):
            sp.valueChanged.connect(self._on_diff_param_changed)

        v.addWidget(params)

        row_c = QHBoxLayout()
        self.btn_scan = QPushButton("Scan & Match")
        self.btn_scan.clicked.connect(self._start_scan)
        row_c.addWidget(self.btn_scan)
        self.lbl_hint = QLabel("Image settings apply instantly; name threshold takes effect on next scan.")
        self.lbl_hint.setStyleSheet("color:#6b7280")
        row_c.addWidget(self.lbl_hint)
        row_c.addStretch(1)
        v.addLayout(row_c)
        return w

    @staticmethod
    def _mk_spin(lo, hi, val, step=1, suffix=""):
        s = QSpinBox()
        s.setRange(lo, hi)
        s.setSingleStep(step)
        s.setValue(val)
        if suffix:
            s.setSuffix(suffix)
        return s

    def _build_left_panel(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)

        v.addWidget(self._section_label("Matched (similarity)"))
        self.lst_pairs = QListWidget()
        self.lst_pairs.currentItemChanged.connect(self._on_pair_selected)
        v.addWidget(self.lst_pairs, 3)

        btn_unpair = QPushButton("Unpair selected ↓")
        btn_unpair.clicked.connect(self._unpair_selected)
        v.addWidget(btn_unpair)

        v.addWidget(self._section_label("Unmatched A"))
        self.lst_ua = QListWidget()
        v.addWidget(self.lst_ua, 2)

        v.addWidget(self._section_label("Unmatched B"))
        self.lst_ub = QListWidget()
        v.addWidget(self.lst_ub, 2)

        btn_pair = QPushButton("↑ Pair selected A + B")
        btn_pair.clicked.connect(self._manual_pair)
        v.addWidget(btn_pair)
        return w

    def _build_right_panel(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)

        self.lbl_pair = QLabel("—")
        self.lbl_pair.setStyleSheet("font-weight:bold;font-size:14px")
        self.lbl_pair.setWordWrap(True)
        v.addWidget(self.lbl_pair)

        nav = QHBoxLayout()
        self.btn_prev = QPushButton("◀ Prev")
        self.btn_prev.clicked.connect(lambda: self._change_page(-1))
        self.spin_page = QSpinBox()
        self.spin_page.setMinimum(1)
        self.spin_page.setMaximum(1)
        self.spin_page.valueChanged.connect(self._on_spin_page)
        self.btn_next = QPushButton("Next ▶")
        self.btn_next.clicked.connect(lambda: self._change_page(1))
        self.lbl_total = QLabel("0 pages")
        self.lbl_warn = QLabel("")
        self.lbl_warn.setStyleSheet("color:#b45309")
        self.btn_export = QPushButton("Export image")
        self.btn_export.setToolTip("Save the current tab's A | B comparison for this page as an image.")
        self.btn_export.clicked.connect(self._export_current)
        btn_fit = QPushButton("Fit")
        btn_fit.clicked.connect(self._fit_current)
        for wdg in (self.btn_prev, self.spin_page, self.btn_next, self.lbl_total):
            nav.addWidget(wdg)
        nav.addWidget(self.lbl_warn)
        nav.addStretch(1)
        nav.addWidget(self.btn_export)
        nav.addWidget(btn_fit)
        v.addLayout(nav)

        self.tabs = QTabWidget()

        # --- Text tab ---
        self.text_view = SideBySide()
        text_split = QSplitter(Qt.Vertical)
        text_split.addWidget(self.text_view)
        bottom = QWidget()
        bl = QVBoxLayout(bottom)
        bl.setContentsMargins(0, 0, 0, 0)
        legend = QLabel(
            '<span style="color:#dc2626">■ Deleted</span>&nbsp;&nbsp;'
            '<span style="color:#16a34a">■ Added</span>&nbsp;&nbsp;'
            '<span style="color:#ea580c">■ Changed</span>&nbsp;&nbsp;— '
            "click an item below to jump to it"
        )
        self.lst_changes = QListWidget()
        self.lst_changes.itemClicked.connect(self._on_change_clicked)
        bl.addWidget(legend)
        bl.addWidget(self.lst_changes)
        text_split.addWidget(bottom)
        text_split.setSizes([620, 220])
        self.tabs.addTab(text_split, "Text / Number diff")

        # --- Pixel tab ---
        self.pixel_view = SideBySide()
        pix_split = QSplitter(Qt.Vertical)
        pix_split.addWidget(self.pixel_view)
        pbottom = QWidget()
        pbl = QVBoxLayout(pbottom)
        pbl.setContentsMargins(0, 0, 0, 0)
        pbl.addWidget(QLabel('<span style="color:#dc2626">■ Image-diff region</span> — click to jump'))
        self.lst_regions = QListWidget()
        self.lst_regions.itemClicked.connect(self._on_region_clicked)
        pbl.addWidget(self.lst_regions)
        pix_split.addWidget(pbottom)
        pix_split.setSizes([620, 220])
        self.tabs.addTab(pix_split, "Chart / Pixel diff")

        v.addWidget(self.tabs, 1)
        return w

    @staticmethod
    def _section_label(text) -> QLabel:
        lbl = QLabel(text)
        lbl.setStyleSheet("font-weight:bold;padding:2px")
        return lbl

    def _build_shortcuts(self):
        QShortcut(QKeySequence(Qt.Key_Left), self, lambda: self._change_page(-1))
        QShortcut(QKeySequence(Qt.Key_Right), self, lambda: self._change_page(1))
        QShortcut(QKeySequence("F"), self, self._fit_current)
        QShortcut(QKeySequence("Ctrl+E"), self, self._export_current)

    # ---- scan / match ------------------------------------------------------
    def _browse(self, line_edit: QLineEdit):
        d = QFileDialog.getExistingDirectory(self, "Choose folder", line_edit.text() or str(Path.home()))
        if d:
            line_edit.setText(d)

    def _start_scan(self):
        a, b = self.le_a.text().strip(), self.le_b.text().strip()
        if not a or not b:
            QMessageBox.warning(self, "Missing folder", "Both folder paths are required.")
            return
        if not Path(a).is_dir() or not Path(b).is_dir():
            QMessageBox.warning(self, "Invalid path", "One of the paths is not a valid folder.")
            return
        self.btn_scan.setEnabled(False)
        self.settings.MATCH_THRESHOLD = self.spin_thr.value()
        self.statusBar().showMessage("Scanning…")
        self._worker = ScanWorker(a, b, self.spin_thr.value())
        self._worker.done.connect(self._on_scan_done)
        self._worker.failed.connect(self._on_scan_failed)
        self._worker.start()

    def _on_scan_done(self, pairs, ua, ub):
        self.btn_scan.setEnabled(True)
        self.pairs = list(pairs)
        self.unmatched_a = list(ua)
        self.unmatched_b = list(ub)
        self._refresh_lists()
        self.statusBar().showMessage(
            f"Matched {len(self.pairs)} pair(s); unmatched A={len(ua)}, B={len(ub)}."
        )

    def _on_scan_failed(self, msg):
        self.btn_scan.setEnabled(True)
        QMessageBox.critical(self, "Scan failed", msg)
        self.statusBar().showMessage("Scan failed.")

    def _refresh_lists(self):
        self.lst_pairs.clear()
        for p in self.pairs:
            it = QListWidgetItem(f"{p.score:5.1f}%   {p.a.name}  ⇄  {p.b.name}")
            it.setToolTip(f"A: {p.a.rel}\nB: {p.b.rel}")
            it.setData(Qt.UserRole, p)
            self.lst_pairs.addItem(it)

        self.lst_ua.clear()
        for f in self.unmatched_a:
            it = QListWidgetItem(f.name)
            it.setToolTip(str(f.rel))
            it.setData(Qt.UserRole, f)
            self.lst_ua.addItem(it)

        self.lst_ub.clear()
        for f in self.unmatched_b:
            it = QListWidgetItem(f.name)
            it.setToolTip(str(f.rel))
            it.setData(Qt.UserRole, f)
            self.lst_ub.addItem(it)

    def _manual_pair(self):
        ia = self.lst_ua.currentItem()
        ib = self.lst_ub.currentItem()
        if not ia or not ib:
            QMessageBox.information(self, "Manual pair",
                                    "Select one item in Unmatched A and one in Unmatched B.")
            return
        fa: PdfFile = ia.data(Qt.UserRole)
        fb: PdfFile = ib.data(Qt.UserRole)
        pair = MatchPair(fa, fb, similarity(fa.name, fb.name))
        self.pairs.append(pair)
        self.pairs.sort(key=lambda p: p.score, reverse=True)
        self.unmatched_a = [f for f in self.unmatched_a if f is not fa]
        self.unmatched_b = [f for f in self.unmatched_b if f is not fb]
        self._refresh_lists()

    def _unpair_selected(self):
        it = self.lst_pairs.currentItem()
        if not it:
            return
        pair: MatchPair = it.data(Qt.UserRole)
        self.pairs = [p for p in self.pairs if p is not pair]
        self.unmatched_a.append(pair.a)
        self.unmatched_b.append(pair.b)
        self.unmatched_a.sort(key=lambda f: str(f.rel).lower())
        self.unmatched_b.sort(key=lambda f: str(f.rel).lower())
        if self.current_pair is pair:
            self.current_pair = None
            self.lbl_pair.setText("—")
        self._refresh_lists()

    # ---- load / display ----------------------------------------------------
    def _on_pair_selected(self, cur, _prev=None):
        if cur is None:
            return
        pair: MatchPair = cur.data(Qt.UserRole)
        self._load_pair(pair)

    def _load_pair(self, pair: MatchPair):
        self.current_pair = pair
        self._page_cache.clear()
        try:
            na = comparer.page_count(pair.a.path)
            nb = comparer.page_count(pair.b.path)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Failed to open file", str(exc))
            return
        self.n_pages = min(na, nb)
        self.lbl_pair.setText(f"A:  {pair.a.rel}\nB:  {pair.b.rel}")
        self.lbl_total.setText(f"{self.n_pages} pages")
        if na != nb:
            self.lbl_warn.setText(f"⚠ Page count differs (A={na}, B={nb}); comparing first {self.n_pages}")
        else:
            self.lbl_warn.setText("")

        self.spin_page.blockSignals(True)
        self.spin_page.setMaximum(max(1, self.n_pages))
        self.spin_page.setValue(1)
        self.spin_page.blockSignals(False)
        self.page_idx = 0
        self._load_page(0)

    def _load_page(self, idx: int):
        if self.current_pair is None or self.n_pages == 0:
            return
        idx = max(0, min(idx, self.n_pages - 1))
        self.page_idx = idx
        pg = self._compute(self.current_pair, idx)
        if pg is None:
            return

        self.text_view.set_images(
            comparer.annotate_text(pg, "a", cfg=self.settings),
            comparer.annotate_text(pg, "b", cfg=self.settings),
        )
        self.pixel_view.set_images(
            comparer.annotate_pixel(pg, "a", cfg=self.settings),
            comparer.annotate_pixel(pg, "b", cfg=self.settings),
        )
        self._fill_change_list(pg)
        self._fill_region_list(pg)

    def _compute(self, pair: MatchPair, idx: int):
        if idx in self._page_cache:
            return self._page_cache[idx]
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            res = comparer.compare_pair(pair.a.path, pair.b.path, pages=[idx], cfg=self.settings)
            pg = res.pages[0] if res.pages else None
            self._page_cache[idx] = pg
            return pg
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Comparison failed", str(exc))
            return None
        finally:
            QApplication.restoreOverrideCursor()

    def _fill_change_list(self, pg: comparer.PageResult):
        self.lst_changes.clear()
        if not pg.text_changes:
            it = QListWidgetItem("(no text differences on this page)")
            it.setFlags(Qt.NoItemFlags)
            self.lst_changes.addItem(it)
            return
        for i, ch in enumerate(pg.text_changes, 1):
            if ch.kind == "replace":
                txt = f"✎  {ch.old}  →  {ch.new}"
            elif ch.kind == "delete":
                txt = f"－  Deleted:  {ch.old}"
            else:
                txt = f"＋  Added:  {ch.new}"
            it = QListWidgetItem(f"{i}. {txt}")
            a_rect = _first_rect(ch.a_boxes, pg.scale)
            b_rect = _first_rect(ch.b_boxes, pg.scale)
            it.setData(Qt.UserRole, (a_rect, b_rect))
            self.lst_changes.addItem(it)

    def _fill_region_list(self, pg: comparer.PageResult):
        self.lst_regions.clear()
        if not pg.pixel_boxes:
            it = QListWidgetItem("(no image differences on this page)")
            it.setFlags(Qt.NoItemFlags)
            self.lst_regions.addItem(it)
            return
        for i, (x0, y0, x1, y1) in enumerate(pg.pixel_boxes, 1):
            it = QListWidgetItem(f"Region {i}   ({x0},{y0})   {x1 - x0}×{y1 - y0}px")
            it.setData(Qt.UserRole, (x0, y0, x1, y1))
            self.lst_regions.addItem(it)

    # ---- navigation / interaction -----------------------------------------
    def _change_page(self, delta):
        if self.n_pages:
            self.spin_page.setValue(self.spin_page.value() + delta)

    def _on_spin_page(self, val):
        self._load_page(val - 1)

    def _fit_current(self):
        self.text_view.fit()
        self.pixel_view.fit()

    def _on_diff_param_changed(self, *_):
        self.settings.RENDER_DPI = self.spin_dpi.value()
        self.settings.PIXEL_DIFF_THRESHOLD = self.spin_pdiff.value()
        self.settings.PIXEL_MIN_AREA = self.spin_pmin.value()
        self.settings.PIXEL_DILATE_ITER = self.spin_dilate.value()
        self._apply_timer.start()   # debounce

    def _reapply_settings(self):
        self._page_cache.clear()
        if self.current_pair is not None:
            self._load_page(self.page_idx)

    def _on_change_clicked(self, item: QListWidgetItem):
        data = item.data(Qt.UserRole)
        if not data:
            return
        a_rect, b_rect = data
        if a_rect:
            self.text_view.view_a.center_on_rect(*a_rect)   # peer follows
        elif b_rect:
            self.text_view.view_b.center_on_rect(*b_rect)

    def _on_region_clicked(self, item: QListWidgetItem):
        rect = item.data(Qt.UserRole)
        if rect:
            self.pixel_view.view_a.center_on_rect(*rect)

    # ---- export ------------------------------------------------------------
    def _export_current(self):
        if self.current_pair is None:
            QMessageBox.information(self, "Export", "Select a matched pair first.")
            return
        pg = self._page_cache.get(self.page_idx)
        if pg is None:
            QMessageBox.information(self, "Export", "Open a page first, then export.")
            return

        if self.tabs.currentIndex() == 0:
            img_a = comparer.annotate_text(pg, "a", cfg=self.settings)
            img_b = comparer.annotate_text(pg, "b", cfg=self.settings)
            kind = "text"
        else:
            img_a = comparer.annotate_pixel(pg, "a", cfg=self.settings)
            img_b = comparer.annotate_pixel(pg, "b", cfg=self.settings)
            kind = "pixel"

        title = (f"{self.current_pair.a.name}   vs   {self.current_pair.b.name}"
                 f"    ·    page {self.page_idx + 1}    ·    {kind} diff")
        combined = comparer.side_by_side_image(
            img_a, img_b, label_a="A · original", label_b="B · compare", title=title
        )

        default = f"{self.current_pair.a.stem}_vs_{self.current_pair.b.stem}_p{self.page_idx + 1}_{kind}.png"
        path, _ = QFileDialog.getSaveFileName(
            self, "Export image", default, "PNG image (*.png);;JPEG image (*.jpg *.jpeg)"
        )
        if not path:
            return
        try:
            out = combined.convert("RGB") if path.lower().endswith((".jpg", ".jpeg")) else combined
            out.save(path)
            self.statusBar().showMessage(f"Exported: {path}")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Export failed", str(exc))


def _first_rect(boxes, scale):
    if not boxes:
        return None
    x0 = min(b.x0 for b in boxes) * scale
    y0 = min(b.y0 for b in boxes) * scale
    x1 = max(b.x1 for b in boxes) * scale
    y1 = max(b.y1 for b in boxes) * scale
    return (x0, y0, x1, y1)


# --------------------------------------------------------------------------- #
def main():
    app = QApplication(sys.argv)
    a = sys.argv[1] if len(sys.argv) > 1 else ""
    b = sys.argv[2] if len(sys.argv) > 2 else ""
    win = MainWindow(prefill_a=a, prefill_b=b)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
