"""遞歸掃描資料夾,搵出所有 PDF(唔理喺邊層 subfolder)。"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PdfFile:
    path: Path      # 完整路徑
    root: Path      # 掃描起點(用嚟計相對路徑)

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def stem(self) -> str:
        return self.path.stem

    @property
    def rel(self) -> Path:
        return self.path.relative_to(self.root)

    def __str__(self) -> str:
        return str(self.rel)


def scan_pdfs(root: str | Path) -> list[PdfFile]:
    """Return every *.pdf under ``root`` (case-insensitive), any depth."""
    root = Path(root).expanduser().resolve()
    if not root.is_dir():
        raise NotADirectoryError(f"唔係一個資料夾: {root}")

    files: list[PdfFile] = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() == ".pdf":
            files.append(PdfFile(path=p, root=root))
    files.sort(key=lambda f: str(f.rel).lower())
    return files
