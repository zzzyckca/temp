"""核心比對邏輯。

每一對配好嘅 PDF、每一頁,做兩樣嘢:

1. 文字 / 數字 diff  — 抽出所有字(連座標),做序列 diff,標出加/刪/改。
                       數字 table 就係一堆字,所以呢個方法直接捉到邊個數字變咗。
2. 像素 diff         — 將兩頁 render 成圖再相減,搵出唔同嘅區域(捉圖表 / 圖形改動,
                       因為 Excel 嘅 graph 通常係向量圖,抽字睇唔到)。

呢個 module 唔 import 任何 GUI,方便單獨測試或者攞去出 report。
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass, field

import fitz  # PyMuPDF
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

from . import config


# --------------------------------------------------------------------------- #
# 資料結構
# --------------------------------------------------------------------------- #
@dataclass
class WordBox:
    x0: float
    y0: float
    x1: float
    y1: float
    text: str


@dataclass
class TextChange:
    kind: str            # 'replace' | 'delete' | 'insert'
    old: str             # A 邊嘅字
    new: str             # B 邊嘅字
    a_boxes: list[WordBox]
    b_boxes: list[WordBox]


@dataclass
class PageResult:
    index: int                       # 0-based 頁碼
    img_a: Image.Image               # A 頁原圖 (RGB)
    img_b: Image.Image               # B 頁原圖 (RGB)
    scale: float                     # px / point = DPI/72(把字座標換算成像素）
    text_changes: list[TextChange]
    pixel_boxes: list[tuple[int, int, int, int]]   # 共同畫布上嘅差異框,兩邊通用
    canvas_size: tuple[int, int]     # 共同畫布 (w, h)


@dataclass
class PairResult:
    n_pages: int                     # 實際比對咗嘅頁數 = min(A, B)
    n_pages_a: int
    n_pages_b: int
    pages: list[PageResult] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# 內部 helper
# --------------------------------------------------------------------------- #
def _render(page: "fitz.Page", dpi: int) -> Image.Image:
    mat = fitz.Matrix(dpi / 72, dpi / 72)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def _words(page: "fitz.Page") -> list[WordBox]:
    try:
        raw = page.get_text("words", sort=True)
    except TypeError:  # 舊版 PyMuPDF 冇 sort 參數
        raw = sorted(page.get_text("words"), key=lambda w: (round(w[1], 1), w[0]))
    boxes: list[WordBox] = []
    for w in raw:
        x0, y0, x1, y1, txt = w[0], w[1], w[2], w[3], w[4]
        if txt.strip():
            boxes.append(WordBox(x0, y0, x1, y1, txt))
    return boxes


def _text_diff(wa: list[WordBox], wb: list[WordBox]) -> list[TextChange]:
    sa = [w.text for w in wa]
    sb = [w.text for w in wb]
    sm = difflib.SequenceMatcher(a=sa, b=sb, autojunk=False)
    out: list[TextChange] = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        out.append(
            TextChange(
                kind=tag,
                old=" ".join(sa[i1:i2]),
                new=" ".join(sb[j1:j2]),
                a_boxes=wa[i1:i2],
                b_boxes=wb[j1:j2],
            )
        )
    return out


def _pad(img: Image.Image, w: int, h: int) -> Image.Image:
    if img.width == w and img.height == h:
        return img
    canvas = Image.new("RGB", (w, h), (255, 255, 255))
    canvas.paste(img, (0, 0))
    return canvas


def _pixel_diff(
    img_a: Image.Image, img_b: Image.Image, cfg=config
) -> tuple[list[tuple[int, int, int, int]], tuple[int, int]]:
    w = max(img_a.width, img_b.width)
    h = max(img_a.height, img_b.height)
    a = np.asarray(_pad(img_a, w, h).convert("L"), dtype=np.int16)
    b = np.asarray(_pad(img_b, w, h).convert("L"), dtype=np.int16)

    diff = np.abs(a - b).astype(np.uint8)
    mask = diff > cfg.PIXEL_DIFF_THRESHOLD
    if cfg.PIXEL_DILATE_ITER > 0:
        mask = ndimage.binary_dilation(mask, iterations=cfg.PIXEL_DILATE_ITER)

    labeled, _n = ndimage.label(mask)
    boxes: list[tuple[int, int, int, int]] = []
    for sl in ndimage.find_objects(labeled):
        if sl is None:
            continue
        y0, y1 = sl[0].start, sl[0].stop
        x0, x1 = sl[1].start, sl[1].stop
        if (x1 - x0) * (y1 - y0) >= cfg.PIXEL_MIN_AREA:
            boxes.append((int(x0), int(y0), int(x1), int(y1)))
    boxes.sort(key=lambda b: (b[1], b[0]))
    return boxes, (w, h)


# --------------------------------------------------------------------------- #
# 對外 API
# --------------------------------------------------------------------------- #
def compare_page(page_a, page_b, index: int, cfg=config) -> PageResult:
    scale = cfg.RENDER_DPI / 72.0
    img_a = _render(page_a, cfg.RENDER_DPI)
    img_b = _render(page_b, cfg.RENDER_DPI)
    text_changes = _text_diff(_words(page_a), _words(page_b))
    pixel_boxes, canvas = _pixel_diff(img_a, img_b, cfg)
    return PageResult(index, img_a, img_b, scale, text_changes, pixel_boxes, canvas)


def page_count(path) -> int:
    doc = fitz.open(path)
    try:
        return doc.page_count
    finally:
        doc.close()


def compare_pair(path_a, path_b, pages=None, cfg=config) -> PairResult:
    """比對兩個 PDF 檔。``pages`` 可以指定只計某幾頁(0-based),None = 全部。"""
    doc_a = fitz.open(path_a)
    doc_b = fitz.open(path_b)
    try:
        na, nb = doc_a.page_count, doc_b.page_count
        n = min(na, nb)
        idxs = range(n) if pages is None else [p for p in pages if 0 <= p < n]
        results = [compare_page(doc_a[i], doc_b[i], i, cfg) for i in idxs]
    finally:
        doc_a.close()
        doc_b.close()
    return PairResult(n_pages=n, n_pages_a=na, n_pages_b=nb, pages=results)


# --------------------------------------------------------------------------- #
# 畫框(GUI 同 export 都用得著）
# --------------------------------------------------------------------------- #
def _text_color(kind: str) -> tuple[int, int, int]:
    return {
        "delete": config.COL_DELETE,
        "insert": config.COL_INSERT,
        "replace": config.COL_REPLACE,
    }[kind]


def annotate_text(page: PageResult, side: str, cfg=config) -> Image.Image:
    """回傳畫咗文字差異框嘅頁面圖。side = 'a' 或 'b'。"""
    img = (page.img_a if side == "a" else page.img_b).copy().convert("RGB")
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay, "RGBA")
    s = page.scale
    for ch in page.text_changes:
        boxes = ch.a_boxes if side == "a" else ch.b_boxes
        if not boxes:
            continue
        col = _text_color(ch.kind)
        for wb in boxes:
            r = [wb.x0 * s, wb.y0 * s, wb.x1 * s, wb.y1 * s]
            draw.rectangle(r, fill=(*col, cfg.FILL_ALPHA))
            draw.rectangle(r, outline=(*col, 255), width=cfg.BOX_WIDTH)
    return Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")


def annotate_pixel(page: PageResult, side: str, cfg=config) -> Image.Image:
    """回傳畫咗像素差異框嘅頁面圖(兩邊用同一組框,對齊)。"""
    base = page.img_a if side == "a" else page.img_b
    img = _pad(base.copy(), *page.canvas_size).convert("RGB")
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay, "RGBA")
    pad = cfg.PIXEL_BOX_PAD
    for (x0, y0, x1, y1) in page.pixel_boxes:
        r = [x0 - pad, y0 - pad, x1 + pad, y1 + pad]
        draw.rectangle(r, fill=(*cfg.COL_PIXEL, cfg.FILL_ALPHA))
        draw.rectangle(r, outline=(*cfg.COL_PIXEL, 255), width=cfg.PIXEL_BOX_WIDTH)
    return Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")


# --------------------------------------------------------------------------- #
# 匯出:把 A / B 兩張標示圖拼成一張(GUI 個 Export 掣 + 日後出 report 都用得著)
# --------------------------------------------------------------------------- #
def _load_font(size: int):
    # 順住試,含 CJK 字體,萬一標題有中文檔名都 render 到
    for name in ("msjh.ttc", "msyh.ttc", "PingFang.ttc", "Arial.ttf", "arial.ttf", "DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    return ImageFont.load_default()


def side_by_side_image(img_a, img_b, label_a="A", label_b="B", title=None):
    """把兩張頁面圖拼成一張有色標題條嘅 A | B 對比圖。"""
    gap, label_h = 16, 30
    title_h = 36 if title else 0
    h = max(img_a.height, img_b.height)

    def _padh(im):
        im = im.convert("RGB")
        if im.height == h:
            return im
        c = Image.new("RGB", (im.width, h), (255, 255, 255))
        c.paste(im, (0, 0))
        return c

    a, b = _padh(img_a), _padh(img_b)
    width = a.width + gap + b.width
    top = title_h + label_h
    canvas = Image.new("RGB", (width, top + h), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)
    font = _load_font(18)

    if title:
        draw.text((8, 8), title, fill=(31, 37, 48), font=font)
    y = title_h
    draw.rectangle([0, y, a.width, y + label_h], fill=config.COL_DELETE)          # A 紅
    draw.rectangle([a.width + gap, y, width, y + label_h], fill=config.COL_INSERT)  # B 綠
    draw.text((10, y + 6), label_a, fill=(255, 255, 255), font=font)
    draw.text((a.width + gap + 10, y + 6), label_b, fill=(255, 255, 255), font=font)

    canvas.paste(a, (0, top))
    canvas.paste(b, (a.width + gap, top))
    return canvas
