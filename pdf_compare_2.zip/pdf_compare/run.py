#!/usr/bin/env python3
"""方便啟動:  python run.py  [資料夾A]  [資料夾B]"""
from pdf_compare.gui import main

if __name__ == "__main__":
    main()
