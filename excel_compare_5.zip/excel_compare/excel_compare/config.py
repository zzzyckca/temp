"""可調參數(集中喺呢度)。"""

# --- 檔名配對 ---
MATCH_THRESHOLD = 85            # 0-100,自動配對嘅最低相似度

# --- 掃描 ---
SCAN_EXTS = (".xlsx", ".xlsm", ".xlsb", ".xls")  # openpyxl 讀唔到舊 .xls;要先另存做 .xlsx

# --- 比對範圍 ---
COMPARE_BY_VALUE = True         # True = 比計算結果(公式 vs 硬值,結果一樣就當冇差異);False = 比公式字串
VALUE_ABS_TOLERANCE = 0.0       # 兩個都係數字時,abs(A-B) <= 呢個就當一樣(浮點容差);0 = 要完全相等
RECALC_VIA_EXCEL = False        # 冇 cached value 嘅檔:True = 逼 Excel 重算先讀(慢啲但穩)
COMPARE_FORMATTING = True       # 比 number format / 字型 / 填色 / 對齊 / 邊框
COMPARE_LAYOUT = True           # 比 merge / 欄闊 / 行高

# --- 並排格線顯示上限(太大就唔畫,淨靠差異表)---
GRID_MAX_ROWS = 400
GRID_MAX_COLS = 80

# --- 格線 highlight 顏色(hex)---
COL_VALUE = "#fde68a"           # 值唔同        黃
COL_FORMAT = "#bfdbfe"          # 淨係格式唔同  藍
COL_ADDED = "#bbf7d0"           # B 有 A 冇     綠
COL_REMOVED = "#fecaca"         # A 有 B 冇     紅


class Settings:
    """可喺介面即時調嘅設定(比對函數收呢個做 cfg)。"""

    def __init__(self):
        self.MATCH_THRESHOLD = MATCH_THRESHOLD
        self.COMPARE_BY_VALUE = COMPARE_BY_VALUE
        self.VALUE_ABS_TOLERANCE = VALUE_ABS_TOLERANCE
        self.RECALC_VIA_EXCEL = RECALC_VIA_EXCEL
        self.COMPARE_FORMATTING = COMPARE_FORMATTING
        self.COMPARE_LAYOUT = COMPARE_LAYOUT
        self.GRID_MAX_ROWS = GRID_MAX_ROWS
        self.GRID_MAX_COLS = GRID_MAX_COLS
        self.COL_VALUE = COL_VALUE
        self.COL_FORMAT = COL_FORMAT
        self.COL_ADDED = COL_ADDED
        self.COL_REMOVED = COL_REMOVED
