# ==========================================================================
# cnb_common_phase3.py  --  PHASE 3 shared ENGINE for the 4 CNB report scripts
# --------------------------------------------------------------------------
# This module is pure machinery: it runs the jobs. It holds NO configuration.
# Every knob (paths, TM1 endpoint, num_processes, prefetch_depth, target_lvl,
# sample_n, robocopy retry, remove_list, the per-report identity) lives in a
# `cfg` dict defined inside each report script, so every value can be tuned
# per script (e.g. sample_n=15 for a test, or a different num_processes).
#
# cfg flows in two ways:
#   * config_mdx(cfg) and run_report(cfg, ...) unpack it directly (parent side).
#   * run_report passes the SAME cfg into the worker pool via initargs; each
#     worker stores it as _cfg and unpacks the bits it needs. cfg is plain data
#     (str/int/None/list), so it pickles cleanly to spawned child processes.
# Each engine function unpacks cfg into bare local names at the top, so the
# body below stays byte-identical to the *_phase2_final.py scripts.
#
# The ONLY thing here that is not config and not a function is the credential
# loader (from connection_tm1 import * + password decode). It must run at
# import time in every process (parent + each spawned worker) so tm1_password
# exists before any TM1 call -- it cannot come from cfg.
#
# config_mdx routes by report name into one of two FAMILIES:
#   * MMR(LOB)              -> two-tuple Spot/MX_2 MDX, pivot index keeps reporting_measure
#   * MMFR(LOB)/MMFRS/MMRS  -> prior-year column + single-tuple MDX, pivot index drops it
# The two report MDX f-strings, the hierarchy hmdx, and the pivot index lists
# are byte-identical to the *_phase2_final.py scripts.
# ==========================================================================

import os
import sys
import time
import shutil
import base64
import hashlib
import logging
import atexit
import queue
import threading
import subprocess
from datetime import datetime

import pandas as pd
import xlwings as xw
import openpyxl as px
from concurrent.futures import ProcessPoolExecutor
from TM1py.Services import TM1Service
from cryptography.fernet import Fernet

# ==========================================================================
# Credential loader (machinery, NOT config). Runs at import in every process.
# connection_tm1.py lives in its own folder; the scripts folder is appended too
# as a belt-and-suspenders for spawned child re-import. These two import paths
# are the only hard-coded paths in this module.
# This block is byte-for-byte your credential loader; do not edit.
# ==========================================================================
sys.path.append("C:/connection")        # connection_tm1.py lives here -- KEEP
sys.path.append("C:/temp1")             # this scripts folder (spawn child re-import safety)
from connection_tm1 import *

decode_key = base64.urlsafe_b64encode(hashlib.sha256(custom_string.encode()).digest())
tm1_password = Fernet(decode_key).decrypt(tm1_token).decode()


# ##########################################################################
# Per-worker globals, filled once by _init_excel_worker. _cfg holds the whole
# config dict so _render_chunk can unpack what it needs without more initargs.
# ##########################################################################
_cfg = None
_mdx = None
_app = None
_wb = None
_sht = None
_sheet_list = None
_proc_temp = None
_acct_map_dict = None
_reporting_period = None
_pivot_index = None
_report_name = None


# ==========================================================================
# Runs ONCE per worker process. Opens one reusable Excel + template; atexit
# closes Excel (NOT robocopy -- subprocess can't spawn its reader thread at
# interpreter shutdown; copying is per-report inside the render loop).
# Unpacks the bits it needs from cfg; template_address is derived from
# template_dir + template_file so no deep path is a module-level constant.
# ==========================================================================
def _init_excel_worker(cfg, mdx, acct_map_dict, reporting_period, pivot_index, log_tag, run_ts):
    global _app, _wb, _sht, _sheet_list, _proc_temp
    global _cfg, _mdx, _acct_map_dict, _reporting_period, _pivot_index, _report_name

    _cfg = cfg
    log_folder    = cfg["log_folder"]
    temp_folder   = cfg["temp_folder"]
    template_dir  = cfg["template_dir"]
    template_file = cfg["template_file"]
    remove_list   = cfg["remove_list"]

    os.makedirs(log_folder, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        filename=os.path.join(log_folder, f"{log_tag}_{run_ts}_worker_{os.getpid()}.log"),
        filemode="a")

    _mdx = mdx
    _acct_map_dict = acct_map_dict
    _reporting_period = reporting_period
    _pivot_index = pivot_index
    _report_name = template_file.split("-")[0]      # prefix used in output filenames

    template_address = template_dir + "\\" + template_file

    _proc_temp = os.path.join(temp_folder, str(os.getpid()))
    os.makedirs(_proc_temp, exist_ok=True)

    _app = xw.App(visible=False)
    _app.display_alerts = False
    _app.screen_updating = False
    _app.calculation = 'manual'          # recalc once per report, not on every cell write

    _wb = _app.books.open(template_address, read_only=True)
    _sht = _wb.sheets["EPM (Data)"]

    # sheets to export = all sheets not in remove_list  (was a list comprehension)
    _sheet_list = []
    for sheet in _wb.sheets:
        if sheet.name not in remove_list:
            _sheet_list.append(sheet.name)

    def _close_worker():
        try:
            if _wb is not None:
                _wb.close()
            if _app is not None:
                _app.quit()
        except Exception as e:
            logging.warning(f"Excel teardown issue: {e}")

    atexit.register(_close_worker)


# ==========================================================================
# Render ONE chunk of OUs on this worker's Excel. A background thread fetches
# the next df from TM1 while the main loop renders the current one. robocopy
# creates the destination folder on demand (no makedirs of UNC paths) and
# auto-retries the whole command up to robocopy_max_tries on a transient
# share failure. Returns a list of (code, caption, ok, err).
# ==========================================================================
def _render_chunk(chunk):
    prefetch_depth      = _cfg["prefetch_depth"]
    tm1_server          = _cfg["tm1_server"]
    tm1_port            = _cfg["tm1_port"]
    tm1_namespace       = _cfg["tm1_namespace"]
    robocopy_max_tries  = _cfg["robocopy_max_tries"]
    robocopy_retry_wait = _cfg["robocopy_retry_wait"]

    results = []
    q = queue.Queue(maxsize=prefetch_depth)   # in-process buffer between fetch thread and render loop

    # --- background prefetcher: TM1 only, never touches Excel/COM ---
    def _fetch_loop():
        try:
            for row in chunk:
                output_path, operating_unit, caption = row
                t0 = time.time()
                try:
                    with TM1Service(address=tm1_server, port=tm1_port,
                                    user=tm1_user, password=tm1_password,
                                    namespace=tm1_namespace, private=True) as tml:
                        this_mdx = _mdx.replace("{operating_unit}", operating_unit)  # local copy; never mutate shared mdx
                        df = tml.cells.execute_mdx_dataframe(this_mdx)
                    q.put((row, df, time.time() - t0, None))
                except Exception as e:
                    q.put((row, None, time.time() - t0, str(e)))
        finally:
            q.put(None)   # sentinel: always sent so the render loop can't hang

    fetcher = threading.Thread(target=_fetch_loop, daemon=True)
    fetcher.start()
    logging.info(f"worker start: {len(chunk)} OUs (prefetch depth {prefetch_depth})")

    # --- main render loop: Excel only ---
    while True:
        item = q.get()
        if item is None:
            break
        row, df, t_fetch, fetch_err = item
        output_path, operating_unit, caption = row

        if fetch_err is not None:
            logging.error(f"SKIP (tm1 failed): {operating_unit} ({caption}) | {fetch_err}")
            results.append((operating_unit, caption, False, f"tm1: {fetch_err}"))
            continue

        try:
            # ---- pivot into EPM (Data) + single recalc ----
            _t_prep = time.time()
            if len(df) == 0:
                df = 0
            else:
                df["cnb_account_full"] = df["cnb_account"].map(_acct_map_dict)
                df["cnb_operating_unit_full"] = caption
                df["X"] = df["cnb_operating_unit_full"] + " " + df["cnb_account_full"] + " " + df["cnb_scenario"]
                df = df.pivot_table(
                    index=_pivot_index,             # family-specific list, passed in via initargs
                    columns="cnb_time_period", values="Value").fillna(0)

            _sht.range("A8").expand().clear_contents()
            _sht.range("A8").value = df
            _app.calculate()                 # single recalc of all sheets
            _t_prep = time.time() - _t_prep

            file_name  = f"{_report_name}-{caption} {_reporting_period}"   # _report_name set per-worker
            temp_xlsx  = os.path.join(_proc_temp, file_name + ".xlsx")
            temp_pdf   = os.path.join(_proc_temp, file_name + ".pdf")
            final_xlsx = os.path.join(output_path, file_name + ".xlsx")
            final_pdf  = os.path.join(output_path, file_name + ".pdf")

            # SaveCopyAs dumps a copy WITHOUT locking it (so we can robocopy + delete now).
            _t_xlsx = time.time()
            _wb.api.SaveCopyAs(temp_xlsx)
            _t_xlsx = time.time() - _t_xlsx

            _t_pdf = time.time()
            _wb.to_pdf(path=temp_pdf, include=_sheet_list)
            _t_pdf = time.time() - _t_pdf

            # robocopy creates the destination folder (incl. deep parents) on demand.
            # Whole-command auto-retry: rc<8 = success; rc>=8 = transient share/UNC
            # failure -> wait and retry, up to robocopy_max_tries.
            _t_copy = time.time()
            for temp, final in [(temp_xlsx, final_xlsx), (temp_pdf, final_pdf)]:
                if not os.path.exists(temp):
                    raise Exception(f"Source not found: {temp}")
                tries = 0
                while True:
                    tries = tries + 1
                    result = subprocess.run(
                        ["robocopy", os.path.dirname(temp), os.path.dirname(final),
                         os.path.basename(temp), "/IS", "/R:3", "/W:1"],
                        capture_output=True)
                    if result.returncode < 8:
                        break
                    if tries >= robocopy_max_tries:
                        raise Exception(f"robocopy rc={result.returncode} for {final} after {tries} tries\n"
                                        + result.stdout.decode(errors='replace'))
                    logging.warning(f"robocopy rc={result.returncode} for {final}, retry {tries}/{robocopy_max_tries}")
                    time.sleep(robocopy_retry_wait)
                os.remove(temp)
            _t_copy = time.time() - _t_copy

            logging.info(f"Done: {operating_unit} ({caption}) | "
                         f"tm1 {t_fetch:.1f}s | prep {_t_prep:.1f}s | "
                         f"xlsx {_t_xlsx:.1f}s | pdf {_t_pdf:.1f}s | copy {_t_copy:.1f}s")
            results.append((operating_unit, caption, True, None))

        except Exception as e:
            logging.error(f"FAILED: {operating_unit} ({caption}) | {e}")
            results.append((operating_unit, caption, False, str(e)))

    fetcher.join()
    return results


# ==========================================================================
# Build the per-OU report MDX + the pivot index for a given report. Unpacks
# report_column + template path from cfg. Shared dimension strings are built
# first (both families use them); the two report FAMILIES then branch for the
# family-specific strings, the pivot index, and the MDX body.
# Returns (mdx, acct_map_dict, reporting_period, pivot_index). The mdx still
# contains the literal {operating_unit} placeholder, swapped per OU in the
# worker's fetch thread.
# ==========================================================================
def config_mdx(cfg):
    report_column = cfg["report_column"]
    template_dir  = cfg["template_dir"]
    template_file = cfg["template_file"]

    template_address = template_dir + "\\" + template_file
    info_df = pd.read_excel(template_address, sheet_name="EPM_info", dtype=str)

    reporting_period = info_df["Current Reporting Year"].iloc[0] + info_df["Current Reporting Month"].iloc[0]
    current_month = info_df["Current Reporting Month"].iloc[0]   # used in the time-period members below

    # ---- shared dimension strings (used by BOTH families) ----

    # cnb_time_period: one DISTINCT(...) block per period value
    time_period_parts = []
    for x in info_df["cnb_time_period"].dropna():
        time_period_parts.append(f""" DISTINCT(
        {{
            DESCENDANTS(
            [cnb_time_period].[cnb_time_period].[{x}.FY] , 99 , LEAVES),
            [cnb_time_period].[cnb_time_period].[{x}.FY],
            [cnb_time_period].[cnb_time_period].[{x}.{current_month}.FYTD]
        }})""")
    time_period_string = ",".join(time_period_parts)

    # cnb_account: member code is the first token of each account label
    acct_parts = []
    for value in info_df["cnb_account"].dropna():
        code = value.split(" ")[0]
        acct_parts.append(f"[cnb_account].[cnb_account].[{code}]")
    acct_string = ",".join(acct_parts)

    # cnb_counter_party_operating_unit: whole value
    counter_party_parts = []
    for value in info_df["cnb_counter_party_operating_unit"].dropna():
        counter_party_parts.append(f"[cnb_counter_party_operating_unit].[cnb_counter_party_operating_unit].[{value}]")
    counter_party_string = ",".join(counter_party_parts)

    # cnb_gaap: whole value
    cnb_gaap_parts = []
    for value in info_df["cnb_gaap"].dropna():
        cnb_gaap_parts.append(f"[cnb_gaap].[cnb_gaap].[{value}]")
    cnb_gaap_string = ",".join(cnb_gaap_parts)

    # cnb_currency: whole value
    cnb_currency_parts = []
    for value in info_df["cnb_currency"].dropna():
        cnb_currency_parts.append(f"[cnb_currency].[cnb_currency].[{value}]")
    cnb_currency_string = ",".join(cnb_currency_parts)

    # cnb_project: whole value
    cnb_project_parts = []
    for value in info_df["cnb_project"].dropna():
        cnb_project_parts.append(f"[cnb_project].[cnb_project].[{value}]")
    cnb_project_string = ",".join(cnb_project_parts)

    # cnb_product: whole value
    cnb_product_parts = []
    for value in info_df["cnb_product"].dropna():
        cnb_product_parts.append(f"[cnb_product].[cnb_product].[{value}]")
    cnb_product_string = ",".join(cnb_product_parts)

    # cnb_source: whole value
    cnb_source_parts = []
    for value in info_df["cnb_source"].dropna():
        cnb_source_parts.append(f"[cnb_source].[cnb_source].[{value}]")
    cnb_source_string = ",".join(cnb_source_parts)

    # account code -> full account label (used to fill cnb_account_full when pivoting)
    acct_list = list(info_df["cnb_account"])
    acct_map_dict = {}
    for acct in acct_list:
        acct_map_dict[acct.split(" ")[0]] = acct

    # ---- family branch: MMR(LOB) vs the MMFR family (MMFR(LOB)/MMFRS/MMRS) ----
    if report_column == "MMR(LOB)":
        # MMR-only extra dimension: cnb_account_spot (same dim, first token)
        acct_spot_parts = []
        for value in info_df["cnb_account_spot"].dropna():
            code = value.split(" ")[0]
            acct_spot_parts.append(f"[cnb_account].[cnb_account].[{code}]")
        acct_string_spot = ",".join(acct_spot_parts)

        # MMR pivot index INCLUDES reporting_measure (Spot / MX_2 live on rows)
        pivot_index = ["X", "cnb_scenario", "reporting_measure", "cnb_operating_unit_full",
                       "cnb_operating_unit", "cnb_account_full", "cnb_account"]

        # ---- MMR report MDX: byte-identical to CNB_mmrlob_phase2_final.py ----
        mdx = f"""SELECT
        {{
            {time_period_string}
        }} ON 0, NON EMPTY
        {{(
        {{
            [cnb_scenario].[cnb_scenario].[Adjusted Actual]
        }}*{{
            [reporting_measure].[reporting_measure].[Spot]
        }}*{{
            [cnb_operating_unit].[cnb_operating_unit].[{{operating_unit}}]
        }}*{{
            {acct_string_spot}
        }}
        ),
        (
        {{
            [cnb_scenario].[cnb_scenario].[Adjusted Actual],
            [cnb_scenario].[cnb_scenario].[Restated Plan]
        }}*{{
            [reporting_measure].[reporting_measure].[MX_2]
        }}*{{
            [cnb_operating_unit].[cnb_operating_unit].[{{operating_unit}}]
        }}*{{
            {acct_string}
        }}
        )}} ON 1
        FROM
        [cnb_reporting]
        WHERE (
        {counter_party_string},
            {cnb_gaap_string},
            {cnb_currency_string},
            {cnb_project_string},
            {cnb_product_string},
            {cnb_source_string})"""

    elif report_column in ("MMFR(LOB)", "MMFRS", "MMRS"):
        prior_year = int(info_df["cnb_time_period"].iloc[0]) - 1     # prior fiscal year = the extra ON-0 column

        # MMFR-only: cnb_scenario on rows (whole value)
        scenario_parts = []
        for value in info_df["cnb_scenario"].dropna():
            scenario_parts.append(f"[cnb_scenario].[cnb_scenario].[{value}]")
        scenario_string = ",".join(scenario_parts)

        # MMFR-only: reporting_measure in WHERE (whole value)
        reporting_measure_parts = []
        for value in info_df["reporting_measure"].dropna():
            reporting_measure_parts.append(f"[reporting_measure].[reporting_measure].[{value}]")
        reporting_measure_string = ",".join(reporting_measure_parts)

        # MMFR pivot index OMITS reporting_measure (it is a fixed WHERE slicer)
        pivot_index = ["X", "cnb_scenario", "cnb_operating_unit_full",
                       "cnb_operating_unit", "cnb_account_full", "cnb_account"]

        # ---- MMFR report MDX: byte-identical to CNB_mmfrlob_phase2_final.py ----
        mdx = f"""SELECT
        {{
            [cnb_time_period].[cnb_time_period].[{prior_year}.FY],
            {time_period_string}
        }} ON 0, NON EMPTY
        {{
            {scenario_string}
        }}*{{
            [cnb_operating_unit].[cnb_operating_unit].[{{operating_unit}}]
        }}*{{
            {acct_string}
        }} ON 1
        FROM
        [cnb_reporting]
        WHERE (
        {counter_party_string},
            {cnb_gaap_string},
            {cnb_currency_string},
            {cnb_project_string},
            {cnb_product_string},
            {reporting_measure_string},
            {cnb_source_string})"""

    else:
        raise ValueError(f"unknown report: {report_column}")

    return mdx, acct_map_dict, reporting_period, pivot_index


# ==========================================================================
# Orchestrate ONE report end-to-end: ou_list -> hierarchy query -> stack ->
# reconcile -> absolute paths -> ProcessPool render -> summary ->
# hierachy_link.xlsx -> cleanup. Unpacks cfg at the top; mdx/acct_map_dict/
# reporting_period/pivot_index come from config_mdx (called in the report
# script). The same cfg is forwarded to the workers via initargs.
# ==========================================================================
def run_report(cfg, mdx, acct_map_dict, reporting_period, pivot_index):
    report_column  = cfg["report_column"]
    root_folder    = cfg["root_folder"]
    ou_list_path   = cfg["ou_list_path"]
    ou_sheet       = cfg["ou_sheet"]
    report_address = cfg["report_address"]
    log_folder     = cfg["log_folder"]
    temp_folder    = cfg["temp_folder"]
    tm1_server     = cfg["tm1_server"]
    tm1_port       = cfg["tm1_port"]
    tm1_namespace  = cfg["tm1_namespace"]
    num_processes  = cfg["num_processes"]
    target_lvl     = cfg["target_lvl"]
    sample_n       = cfg["sample_n"]

    # short, filename-safe log prefix from root_folder: lowercase + keep alnum
    # ("MMR(LOB)" -> "mmrlob", "MMFR(LOB)" -> "mmfrlob", "MMFRS" -> "mmfrs", ...)
    log_tag = ""
    for ch in root_folder.lower():
        if ch.isalnum():
            log_tag = log_tag + ch

    os.makedirs(log_folder, exist_ok=True)
    run_ts = datetime.now().strftime("%Y%m%d_%H%M%S")   # one timestamp for the whole run, shared with all workers
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        filename=os.path.join(log_folder, f"{log_tag}_{run_ts}_main.log"),
        filemode="a")

    os.makedirs(temp_folder, exist_ok=True)
    start_time = time.time()

    # ---- OU set for THIS report: ou_list.xlsx, sheet "ou", column report_column ----
    #      (inline pandas: take that one column, code = first token; kept as-is)
    ou_raw = pd.read_excel(ou_list_path, sheet_name=ou_sheet)
    ou_list = ou_raw[report_column].str.split(" ").str[0].dropna().tolist()
    logging.info(f"ou_list: {len(ou_list)} OUs from column '{report_column}'")

    # ======================================================================
    # OU hierarchy query + folder-path stack.  Explicit style: the raw-result
    # parse and the path stack are plain for-loops/if-else. The `hmdx` f-string
    # is byte-identical to your build_folder_structure.py.
    # Query is full-tree; the ou_list filter is applied AFTER paths are built.
    # ======================================================================
    with TM1Service(address=tm1_server, port=tm1_port,
                    user=tm1_user, password=tm1_password,
                    namespace=tm1_namespace, private=True) as tml:
        hmdx = f"""SELECT
        {{
            [}}ElementAttributes_cnb_operating_unit].[}}ElementAttributes_cnb_operating_unit].[Caption],
            [}}ElementAttributes_cnb_operating_unit].[}}ElementAttributes_cnb_operating_unit].[CNB Level Number]
        }} ON 0,
        {{
            DISTINCT(
                {{
                    DESCENDANTS(
                    [cnb_operating_unit].[cnb_operating_unit].[0])
                }})
        }} ON 1
        FROM
        [}}ElementAttributes_cnb_operating_unit]"""
        raw = tml.cubes.cells.execute_mdx_raw(hmdx)

    axes = raw["Axes"]

    # column member names  (was a list comprehension)
    col_names = []
    for t in axes[0]["Tuples"]:
        col_names.append(t["Members"][0]["Name"])

    # row member names  (was a list comprehension)
    row_names = []
    for t in axes[1]["Tuples"]:
        row_names.append(t["Members"][0]["Name"])

    cells = raw["Cells"]
    n_cols = len(col_names)

    # walk each OU row -> (Caption, Level)  (ternary expanded to if/else)
    rows_h = []
    for i, row_elem in enumerate(row_names):
        base = i * n_cols
        caption = cells[base + 0].get("Value")
        level = cells[base + 1].get("Value")
        if level is not None:
            level_value = int(float(level))
        else:
            level_value = None
        rows_h.append((caption, level_value))

    df = pd.DataFrame(rows_h, columns=["Caption", "Level"])
    df["Caption"] = df["Caption"].str.replace(r'[<>:"/\\|?*]', '', regex=True)
    # df["Caption"] = df["Caption"].str.replace("- ", "").str.replace(" ", "_")
    df["Code"] = df["Caption"].str.split(" ").str[0]

    # we only ever track folders down to target_lvl, so the stack needs exactly
    # target_lvl+1 slots (levels 0..target_lvl). Levels deeper than target_lvl
    # never set the stack, so they keep (fold into) their level-<=target_lvl parent.
    stack = [None] * (target_lvl + 1)
    paths = []
    for caption, lvl in zip(df["Caption"], df["Level"]):
        lvl = int(lvl)
        if 0 < lvl <= target_lvl:
            stack[lvl] = caption
            for j in range(lvl + 1, target_lvl + 1):   # clear the deeper tracked levels
                stack[j] = None

        # relative path = backslash-join of the non-empty stack entries
        stack_parts = []
        for x in stack:
            if x is not None:
                stack_parts.append(x)
        paths.append("\\".join(stack_parts))

    df["Path"] = paths                              # relative paths
    df = df[["Code", "Caption", "Level", "Path"]]
    df = df[df["Code"].isin(ou_list)]

    # reconcile: any OU asked for in ou_list but NOT found in the TM1 hierarchy
    # would otherwise be silently dropped (no report, no error) -- flag it.
    matched_codes = set(df["Code"])
    missing_codes = []
    for code in ou_list:
        if code not in matched_codes:
            missing_codes.append(code)
    if missing_codes:
        logging.warning(f"{len(missing_codes)} OU(s) in ou_list NOT found in TM1 hierarchy: {missing_codes}")
    logging.info(f"requested {len(ou_list)} OUs from ou_list, matched {len(df)} in hierarchy")

    # ---- Phase 2: absolute final path = results\{root_folder}\{reporting_period}\{relative}\ ----
    folder_path = f"{report_address}\\{root_folder}\\{reporting_period}\\"
    df["Path"] = folder_path + df["Path"]

    # tasks: (output_path, code, caption)  -- order follows hierarchy (parents first)
    rows = list(zip(df["Path"], df["Code"], df["Caption"]))
    if sample_n is not None:
        rows = rows[:sample_n]

    # round-robin split into one chunk per worker (interleaves big/small OUs so
    # chunks stay balanced); skip empty chunks when rows < num_processes.
    # (was two list comprehensions, now one loop)
    chunks = []
    for i in range(num_processes):
        chunk = rows[i::num_processes]
        if chunk:
            chunks.append(chunk)

    # ======================================================================
    # Render: each worker renders its chunk with an internal prefetch thread.
    # robocopy makes the deep destination folders as it copies.
    # ======================================================================
    logging.info(f"START: {len(rows)} OUs across {len(chunks)} workers "
                 f"(prefetch depth {cfg['prefetch_depth']}) -> {report_address}\\{root_folder}\\{reporting_period}")
    results = []
    with ProcessPoolExecutor(max_workers=num_processes,
                             initializer=_init_excel_worker,
                             initargs=(cfg, mdx, acct_map_dict, reporting_period,
                                       pivot_index, log_tag, run_ts)) as ex:
        for chunk_results in ex.map(_render_chunk, chunks):
            results.extend(chunk_results)

    # ---- overall success/fail summary  (failed-list was a comprehension) ----
    failed = []
    for r in results:
        if not r[2]:
            failed.append(r)
    elapsed_minutes = round((time.time() - start_time) / 60, 0)
    logging.info(f"ALL DONE in {elapsed_minutes} mins | "
                 f"{len(results) - len(failed)} ok / {len(failed)} failed")
    if failed:
        logging.warning("Failed OUs:")
        for code, caption, _, err in failed:
            logging.warning(f"  - {code} ({caption}): {err}")

    # ======================================================================
    # Rebuild hierachy_link.xlsx from the in-memory df (no hierachy.xlsx now).
    # df.to_excel writes: A=index, B=Code, C=Caption, D=Level, E=Path  -> the
    # absolute folder path lands in column 5 (E), which the link logic expects.
    # Written directly to results\{root_folder}\{reporting_period}\ (short path, < 260).
    # ======================================================================
    link_dir  = f"{report_address}\\{root_folder}\\{reporting_period}"
    os.makedirs(link_dir, exist_ok=True)        # link_dir is a short path (<260); safe even if nothing rendered into it
    link_xlsx = os.path.join(link_dir, "hierachy_link.xlsx")
    df.to_excel(link_xlsx)

    wb = px.load_workbook(link_xlsx)
    ws = wb[wb.sheetnames[0]]
    for row in range(2, ws.max_row + 1):
        file_path = ws.cell(row, 5).value          # absolute folder path
        if not file_path:                          # skip empty rows
            continue
        rel = file_path.replace(link_dir, "")      # strip the link_dir prefix -> relative
        rel_formula = ('=LEFT(CELL("filename",$A$1),FIND("[",CELL("filename",$A$1))-2)'
                       + '&"' + rel + '"')
        ws.cell(row, 5).value = rel_formula
        ws.cell(row, 6).value = f"=HYPERLINK(E{row})"
        ws.cell(row, 6).style = "Hyperlink"
    ws.column_dimensions["E"].hidden = True
    ws.cell(1, 6).value = "Path Link"
    wb.save(link_xlsx)
    logging.info(f"hierachy_link.xlsx written -> {link_xlsx}")

    # ---- cleanup: remove per-worker pid temp subfolders under temp_folder ----
    for name in os.listdir(temp_folder):
        sub = os.path.join(temp_folder, name)
        if os.path.isdir(sub):
            shutil.rmtree(sub, ignore_errors=True)
    logging.info("temp pid folders cleaned up.")
