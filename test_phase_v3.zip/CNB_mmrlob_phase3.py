# ==========================================================================
# CNB MMR(LOB) report generator  --  PHASE 3
# All engine logic lives in cnb_common_phase3.py. This script is just a
# self-contained cfg dict + import + the two calls. Every knob below can be
# tuned for this report alone (e.g. sample_n=15 for a test run, or a different
# num_processes / prefetch_depth) without touching common.
# Run: python CNB_mmrlob_phase3.py
# ==========================================================================

cfg = {
    # ---- per-report identity (column in ou_list.xlsx / results subfolder / template) ----
    "report_column":  "MMR(LOB)",
    "root_folder":    "MMR(LOB)",
    "template_file":  "MMR(LOB)-template.xlsx",

    # ---- paths: full hard-coded UNC (no base_path) ----
    "template_dir":   "\\\\maple.fg.rbc.com\\data\\Toronto\\wrkgrp\\wrkgrp11\\Shared Services Reporting Centre\\Individual Folders\\Leo\\CNB Project\\templates",
    "ou_list_path":   "\\\\maple.fg.rbc.com\\data\\Toronto\\wrkgrp\\wrkgrp11\\Shared Services Reporting Centre\\Individual Folders\\Leo\\CNB Project\\templates\\ou_list.xlsx",
    "report_address": "\\\\maple.fg.rbc.com\\data\\Toronto\\wrkgrp\\wrkgrp11\\Shared Services Reporting Centre\\Individual Folders\\Leo\\CNB Project\\results",
    "ou_sheet":       "ou",
    "temp_folder":    "C:\\cnb_project\\",
    "log_folder":     "C:\\temp1",

    # ---- TM1 endpoint ----
    "tm1_server":     "SE140939.fg.rbc.com",
    "tm1_port":       "13111",
    "tm1_namespace":  "maple",

    # ---- per-script tunables ----
    "num_processes":  8,        # Excel render workers (= CPU cores). Tune per script if needed.
    "prefetch_depth": 2,        # OUs the fetch thread may run ahead (in-process queue size).
    "target_lvl":     4,        # folder depth; OUs deeper than this fold into their level-4 parent.
    "sample_n":       None,     # None = full run; set e.g. 15 to render only the first 15 OUs.

    # ---- robocopy whole-command retry ----
    "robocopy_max_tries":  3,
    "robocopy_retry_wait": 2,

    # ---- sheets NOT exported to PDF ----
    "remove_list": ['EPM_ControlSheet', 'Cognos_Office_Connection_Cache', 'Title',
                    'EPM (Data)', 'List', 'Hierarchy', 'EPM_info'],
}

from cnb_common_phase3 import *

if __name__ == "__main__":
    mdx, acct_map_dict, reporting_period, pivot_index = config_mdx(cfg)
    run_report(cfg, mdx, acct_map_dict, reporting_period, pivot_index)
