r"""遞歸掃描資料夾,搵出所有 PDF(唔理喺邊層 subfolder)。

Windows 長路徑:標準 API 有 260 字(MAX_PATH)全路徑上限,深層 UNC 檔會掃唔到。
我哋喺 Windows 度自動加 \\?\ 前綴(UNC 變 \\?\UNC\…),繞過呢個限制。
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _extended_length_path(path_str: str, is_windows: bool | None = None) -> str:
    r"""喺 Windows 加 \\?\ 前綴,令 >260 字嘅路徑都開得到。非 Windows 原樣返回。"""
    if is_windows is None:
        is_windows = os.name == "nt"
    if not is_windows:
        return path_str
    p = os.path.abspath(path_str)          # 純字串運算,唔會掂 filesystem
    if p.startswith("\\\\?\\"):
        return p
    if p.startswith("\\\\"):               # UNC:\\server\share\…
        return "\\\\?\\UNC\\" + p[2:]
    return "\\\\?\\" + p                    # 本機碟:C:\…


@dataclass(frozen=True)
class PdfFile:
    path: Path      # 完整路徑(Windows 上可能帶 \\?\ 前綴,方便開檔)
    root: Path      # 掃描起點(用嚟計相對路徑)

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def stem(self) -> str:
        return self.path.stem

    @property
    def rel(self) -> Path:
        try:
            return self.path.relative_to(self.root)
        except ValueError:
            return Path(self.path.name)

    def __str__(self) -> str:
        return str(self.rel)


def scan_pdfs(root: str | Path) -> list[PdfFile]:
    """Return every *.pdf under ``root`` (case-insensitive), any depth."""
    root_str = os.path.abspath(os.path.expanduser(str(root)))
    walk_root = _extended_length_path(root_str)
    if not os.path.isdir(walk_root):
        raise NotADirectoryError(f"唔係一個資料夾 / Not a folder: {root}")

    root_path = Path(walk_root)
    files: list[PdfFile] = []
    # onerror 令個別權限 / 讀取錯誤唔會拖冧成個掃描
    for dirpath, _dirnames, filenames in os.walk(walk_root, onerror=lambda _e: None):
        for fn in filenames:
            if fn.lower().endswith(".pdf"):
                files.append(PdfFile(path=Path(dirpath) / fn, root=root_path))
    files.sort(key=lambda f: str(f).lower())
    return files
