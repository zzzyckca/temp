r"""把 .xlsb / .xls 轉做 .xlsx 俾 openpyxl 讀(保留格式)。

- Windows + Excel:用 COM(pywin32)開檔另存 .xlsx —— number format / 日期 / 公式 /
  字型等全部保留。
- 否則(或者冇 Excel):試 LibreOffice ``soffice --convert-to xlsx``。
- 轉一次就 cache;臨時檔喺程式退出時清走。
- openpyxl 本身可以開嘅(.xlsx / .xlsm)唔會郁。
"""
from __future__ import annotations

import atexit
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

_CACHE: dict = {}
_TMPDIR: str | None = None
_LO_PROFILE: str | None = None

CONVERT_EXTS = (".xlsb", ".xls")


def _tmpdir() -> str:
    global _TMPDIR
    if _TMPDIR is None:
        _TMPDIR = tempfile.mkdtemp(prefix="xlcmp_")
        atexit.register(lambda: shutil.rmtree(_TMPDIR, ignore_errors=True))
    return _TMPDIR


def _strip_ext_prefix(p: str) -> str:
    r"""還原 \\?\ 長路徑前綴做普通路徑(Excel / soffice 唔食嗰個前綴)。"""
    if p.startswith("\\\\?\\UNC\\"):
        return "\\\\" + p[8:]
    if p.startswith("\\\\?\\"):
        return p[4:]
    return p


def needs_conversion(path) -> bool:
    return str(path).lower().endswith(CONVERT_EXTS)


def _key(path):
    try:
        st = os.stat(path)
        return (str(path), int(st.st_mtime), st.st_size)
    except OSError:
        return (str(path), 0, 0)


def ensure_xlsx(path):
    """回傳一個 openpyxl 讀得到嘅 .xlsx 路徑;必要時轉檔並 cache。"""
    if not needs_conversion(path):
        return path
    key = _key(path)
    cached = _CACHE.get(key)
    if cached and os.path.exists(cached):
        return cached

    src = _strip_ext_prefix(str(path))
    dst = os.path.join(_tmpdir(), f"{Path(src).stem}_{abs(hash(key)) % 10 ** 8}.xlsx")

    last_err = None
    for convert in (_convert_excel, _convert_libreoffice):
        try:
            convert(src, dst)
            if os.path.exists(dst):
                _CACHE[key] = dst
                return dst
        except Exception as exc:  # noqa: BLE001
            last_err = exc
    raise RuntimeError(
        f"開唔到 {Path(src).name}:.xlsb / .xls 需要 Excel 或 LibreOffice 先轉到 .xlsx。"
        f"（{last_err}）"
    )


def _convert_excel(src, dst):
    """Windows + Excel(pywin32 COM)。"""
    import pythoncom
    import win32com.client as win32

    pythoncom.CoInitialize()          # 喺 worker thread 用 COM 要 init
    excel = None
    try:
        excel = win32.DispatchEx("Excel.Application")   # 開一個獨立 instance
        excel.Visible = False
        excel.DisplayAlerts = False
        wb = excel.Workbooks.Open(os.path.abspath(src), ReadOnly=True, UpdateLinks=0)
        wb.SaveAs(os.path.abspath(dst), FileFormat=51)  # 51 = xlOpenXMLWorkbook (.xlsx)
        wb.Close(SaveChanges=False)
    finally:
        if excel is not None:
            try:
                excel.Quit()
            except Exception:  # noqa: BLE001
                pass
        pythoncom.CoUninitialize()


def _lo_profile() -> str:
    global _LO_PROFILE
    if _LO_PROFILE is None:
        _LO_PROFILE = "file://" + tempfile.mkdtemp(prefix="lo_prof_", dir=_tmpdir())
    return _LO_PROFILE


def _convert_libreoffice(src, dst):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise FileNotFoundError("LibreOffice 唔喺 PATH")
    outdir = os.path.dirname(dst)
    subprocess.run(
        [soffice, "-env:UserInstallation=" + _lo_profile(), "--headless",
         "--convert-to", "xlsx", "--outdir", outdir, os.path.abspath(src)],
        check=True, timeout=180, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    produced = os.path.join(outdir, Path(src).stem + ".xlsx")
    if os.path.abspath(produced) != os.path.abspath(dst) and os.path.exists(produced):
        shutil.move(produced, dst)
