"""excel_compare — 比對兩個 Excel workbook(逐個共同 worksheet、cell 值 + 格式)。"""
__version__ = "0.1.0"
