r"""遞歸掃描資料夾,搵出所有 Excel 檔(唔理喺邊層 subfolder)。

Windows 長路徑:標準 API 有 260 字(MAX_PATH)上限,深層 UNC 檔會掃唔到。
喺 Windows 自動加 \\?\ 前綴(UNC 變 \\?\UNC\…)繞過。
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from . import config


def _extended_length_path(path_str: str, is_windows: bool | None = None) -> str:
    r"""喺 Windows 加 \\?\ 前綴。非 Windows 原樣返回。"""
    if is_windows is None:
        is_windows = os.name == "nt"
    if not is_windows:
        return path_str
    p = os.path.abspath(path_str)
    if p.startswith("\\\\?\\"):
        return p
    if p.startswith("\\\\"):
        return "\\\\?\\UNC\\" + p[2:]
    return "\\\\?\\" + p


@dataclass(frozen=True)
class XlFile:
    path: Path
    root: Path

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def stem(self) -> str:
        return self.path.stem

    @property
    def rel(self) -> Path:
        try:
            return self.path.relative_to(self.root)
        except ValueError:
            return Path(self.path.name)

    def __str__(self) -> str:
        return str(self.rel)


def scan_excels(root: str | Path) -> list[XlFile]:
    """Return every Excel file under ``root`` (any depth). 略過 Excel 暫存檔 ~$。"""
    root_str = os.path.abspath(os.path.expanduser(str(root)))
    walk_root = _extended_length_path(root_str)
    if not os.path.isdir(walk_root):
        raise NotADirectoryError(f"唔係一個資料夾 / Not a folder: {root}")

    root_path = Path(walk_root)
    exts = tuple(e.lower() for e in config.SCAN_EXTS)
    out: list[XlFile] = []
    for dirpath, _dirs, filenames in os.walk(walk_root, onerror=lambda _e: None):
        for fn in filenames:
            if fn.startswith("~$"):
                continue
            if fn.lower().endswith(exts):
                out.append(XlFile(path=Path(dirpath) / fn, root=root_path))
    out.sort(key=lambda f: str(f).lower())
    return out
