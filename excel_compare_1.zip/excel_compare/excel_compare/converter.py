r"""把 .xlsb / .xls 轉做 .xlsx 俾 openpyxl 讀(保留格式)。

做法:
  1. 先把來源檔**複製去一個短嘅本機臨時路徑**。咁做解決咗兩件事——
     • Excel COM 開 >260 字嘅長 UNC 路徑會失敗;
     • 網絡嚟嘅檔會觸發 Excel「受保護的檢視 / Protected View」擋自動化,
       本機 copy(唔帶 mark-of-the-web)就唔會。
  2. Windows + Excel:用 COM(pywin32)Open -> SaveAs .xlsx(格式全保留)。
  3. 冇 Excel 就試 LibreOffice `soffice --convert-to xlsx`。
  4. 轉一次就 cache;臨時檔喺程式退出時清走。

openpyxl 本身開到嘅(.xlsx / .xlsm)唔會郁。
"""
from __future__ import annotations

import atexit
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

_CACHE: dict = {}
_TMPDIR = None
_LO_PROFILE = None

CONVERT_EXTS = (".xlsb", ".xls")


def _tmpdir():
    global _TMPDIR
    if _TMPDIR is None:
        _TMPDIR = tempfile.mkdtemp(prefix="xlcmp_")
        atexit.register(lambda: shutil.rmtree(_TMPDIR, ignore_errors=True))
    return _TMPDIR


def _strip_ext_prefix(p: str) -> str:
    if p.startswith("\\\\?\\UNC\\"):
        return "\\\\" + p[8:]
    if p.startswith("\\\\?\\"):
        return p[4:]
    return p


def needs_conversion(path) -> bool:
    return str(path).lower().endswith(CONVERT_EXTS)


def _key(path):
    try:
        st = os.stat(path)
        return (str(path), int(st.st_mtime), st.st_size)
    except OSError:
        return (str(path), 0, 0)


def ensure_xlsx(path):
    """回傳一個 openpyxl 讀得到嘅 .xlsx 路徑;必要時轉檔並 cache。"""
    if not needs_conversion(path):
        return path

    key = _key(path)
    cached = _CACHE.get(key)
    if cached and os.path.exists(cached):
        return cached

    orig = str(path)
    display = Path(_strip_ext_prefix(orig)).name
    ext = Path(_strip_ext_prefix(orig)).suffix.lower()
    tag = abs(hash(key)) % 10 ** 8

    # 1) 複製去短嘅本機臨時檔(解決長 UNC + Protected View)
    local_src = os.path.join(_tmpdir(), f"src_{tag}{ext}")
    try:
        shutil.copyfile(orig, local_src)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"複製唔到 {display}:{exc}") from exc

    dst = os.path.join(_tmpdir(), f"conv_{tag}.xlsx")

    # 2) 轉檔:Excel 行先,唔得先 LibreOffice
    errors = []
    for name, convert in (("Excel", _convert_excel), ("LibreOffice", _convert_libreoffice)):
        try:
            convert(local_src, dst)
            if os.path.exists(dst):
                _CACHE[key] = dst
                return dst
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{name}: {exc}")

    raise RuntimeError(
        f"轉唔到 {display} 做 .xlsx。\n" + "\n".join(errors)
        + "\n(如果 Excel 嗰行話搵唔到 win32com,請喺你正用嗰個 Python 環境行: pip install pywin32)"
    )


def _convert_excel(src, dst):
    """Windows + Excel(pywin32 COM)。src / dst 已經係短嘅本機路徑。"""
    try:
        import pythoncom
        import win32com.client as win32
    except ImportError as exc:
        raise RuntimeError("win32com 未裝 (pip install pywin32)") from exc

    pythoncom.CoInitialize()
    excel = None
    try:
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        try:
            excel.AskToUpdateLinks = False
        except Exception:  # noqa: BLE001
            pass
        try:
            excel.AutomationSecurity = 3   # msoAutomationSecurityForceDisable
        except Exception:  # noqa: BLE001
            pass
        wb = excel.Workbooks.Open(os.path.abspath(src), ReadOnly=True, UpdateLinks=0)
        wb.SaveAs(os.path.abspath(dst), FileFormat=51)   # 51 = .xlsx
        wb.Close(SaveChanges=False)
    finally:
        if excel is not None:
            try:
                excel.Quit()
            except Exception:  # noqa: BLE001
                pass
        pythoncom.CoUninitialize()


def _lo_profile():
    global _LO_PROFILE
    if _LO_PROFILE is None:
        _LO_PROFILE = "file://" + tempfile.mkdtemp(prefix="lo_prof_", dir=_tmpdir())
    return _LO_PROFILE


def _convert_libreoffice(src, dst):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        raise FileNotFoundError("LibreOffice 唔喺 PATH")
    outdir = os.path.dirname(dst)
    subprocess.run(
        [soffice, "-env:UserInstallation=" + _lo_profile(), "--headless",
         "--convert-to", "xlsx", "--outdir", outdir, os.path.abspath(src)],
        check=True, timeout=180, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    produced = os.path.join(outdir, Path(src).stem + ".xlsx")
    if os.path.abspath(produced) != os.path.abspath(dst) and os.path.exists(produced):
        shutil.move(produced, dst)
