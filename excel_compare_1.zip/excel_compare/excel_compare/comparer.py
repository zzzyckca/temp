"""核心比對邏輯(用 openpyxl,保留格式)。

- 只比對兩個 workbook 都有嘅 worksheet(交集);多出嚟嘅會列出但唔比。
- 每個共同 sheet,逐個 cell 比:值(公式 / 文字 / 數字)、格式(number format、
  字型、填色、對齊、邊框),再加 layout(merge、欄闊、行高)。
- 唔用 pandas,所以格式全部 care 到。

呢個 module 唔 import GUI,方便測試 / 出報告。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from openpyxl import Workbook, load_workbook
from openpyxl.utils import column_index_from_string, get_column_letter

from . import config, converter


# --------------------------------------------------------------------------- #
# 資料結構
# --------------------------------------------------------------------------- #
@dataclass
class CellDiff:
    sheet: str
    ref: str            # "B7"、"col C"、"row 3"、或 merge range
    kind: str           # value|number_format|font|fill|alignment|border|merge|col_width|row_height
    a: str
    b: str


@dataclass
class SheetDiff:
    name: str
    a_rows: int
    a_cols: int
    b_rows: int
    b_cols: int
    diffs: list = field(default_factory=list)


@dataclass
class WorkbookDiff:
    common: list          # 共同 sheet 名(照 A 次序)
    only_a: list          # 淨係 A 有
    only_b: list          # 淨係 B 有
    sheets: list          # list[SheetDiff]

    @property
    def total_diffs(self) -> int:
        return sum(len(s.diffs) for s in self.sheets)


# --------------------------------------------------------------------------- #
# 格式 signature / 顯示
# --------------------------------------------------------------------------- #
def _color(c):
    if c is None:
        return None
    rgb = getattr(c, "rgb", None)
    return rgb.upper() if isinstance(rgb, str) else None


def _font_sig(f):
    return (f.name, f.size, bool(f.bold), bool(f.italic), f.underline, _color(f.color))


def _font_repr(f):
    parts = []
    if f.name:
        parts.append(str(f.name))
    if f.size:
        parts.append(f"{f.size:g}pt")
    if f.bold:
        parts.append("bold")
    if f.italic:
        parts.append("italic")
    if f.underline:
        parts.append("underline")
    col = _color(f.color)
    if col and col[-6:] not in ("000000",):
        parts.append("#" + col[-6:])
    return " ".join(parts) or "default"


def _fill_sig(fill):
    if fill is None or not fill.patternType:
        return None
    return (fill.patternType, _color(fill.fgColor), _color(fill.bgColor))


def _fill_repr(fill):
    sig = _fill_sig(fill)
    if not sig:
        return "none"
    pt, fg, _bg = sig
    return f"{pt} #{(fg or '------')[-6:]}"


def _align_sig(a):
    return (a.horizontal, a.vertical, bool(a.wrap_text))


def _align_repr(a):
    return f"h={a.horizontal or '-'} v={a.vertical or '-'}" + (" wrap" if a.wrap_text else "")


def _border_sig(b):
    def s(side):
        return side.style if side else None
    return (s(b.left), s(b.right), s(b.top), s(b.bottom))


def _border_repr(b):
    names = ["L", "R", "T", "B"]
    on = [n for n, v in zip(names, _border_sig(b)) if v]
    return "+".join(on) if on else "none"


# --------------------------------------------------------------------------- #
# 內部 helper
# --------------------------------------------------------------------------- #
def _coord(r, c):
    return f"{get_column_letter(c)}{r}"


def _vrepr(v):
    if v is None:
        return "(empty)"
    s = str(v)
    return s if len(s) <= 200 else s[:200] + "…"


def _grid_values(ws, maxr, maxc):
    if maxr == 0 or maxc == 0:
        return []
    return list(ws.iter_rows(min_row=1, max_row=maxr, min_col=1, max_col=maxc, values_only=True))


def _col_width(ws, letter):
    d = ws.column_dimensions.get(letter)
    return round(d.width, 2) if d is not None and d.width is not None else None


def _row_height(ws, idx):
    d = ws.row_dimensions.get(idx)
    return round(d.height, 2) if d is not None and d.height is not None else None


def _sortkey(ref):
    m = re.match(r"^([A-Z]+)(\d+)$", ref)
    if m:
        return (int(m.group(2)), column_index_from_string(m.group(1)), "")
    return (10 ** 9, 0, ref)


def _layout_diffs(wsa, wsb, name, diffs):
    ma = {str(x) for x in wsa.merged_cells.ranges}
    mb = {str(x) for x in wsb.merged_cells.ranges}
    for rng in sorted(ma - mb):
        diffs.append(CellDiff(name, rng, "merge", "merged", "not merged"))
    for rng in sorted(mb - ma):
        diffs.append(CellDiff(name, rng, "merge", "not merged", "merged"))
    for col in sorted(set(wsa.column_dimensions.keys()) | set(wsb.column_dimensions.keys())):
        wa, wb = _col_width(wsa, col), _col_width(wsb, col)
        if wa != wb:
            diffs.append(CellDiff(name, f"col {col}", "col_width", str(wa), str(wb)))
    for row in sorted(set(wsa.row_dimensions.keys()) | set(wsb.row_dimensions.keys())):
        ha, hb = _row_height(wsa, row), _row_height(wsb, row)
        if ha != hb:
            diffs.append(CellDiff(name, f"row {row}", "row_height", str(ha), str(hb)))


def _compare_sheet(wsa, wsb, name, cfg) -> SheetDiff:
    ar, ac = wsa.max_row or 0, wsa.max_column or 0
    br, bc = wsb.max_row or 0, wsb.max_column or 0
    maxr, maxc = max(ar, br), max(ac, bc)
    diffs: list[CellDiff] = []

    # --- 值(快)---
    va = _grid_values(wsa, maxr, maxc)
    vb = _grid_values(wsb, maxr, maxc)
    for r in range(maxr):
        rowa = va[r] if r < len(va) else ()
        rowb = vb[r] if r < len(vb) else ()
        for c in range(maxc):
            av = rowa[c] if c < len(rowa) else None
            bv = rowb[c] if c < len(rowb) else None
            if av != bv:
                diffs.append(CellDiff(name, _coord(r + 1, c + 1), "value", _vrepr(av), _vrepr(bv)))

    # --- 格式(可選,較慢)---
    if cfg.COMPARE_FORMATTING and maxr and maxc:
        for r in range(1, maxr + 1):
            for c in range(1, maxc + 1):
                ca, cb = wsa.cell(r, c), wsb.cell(r, c)
                if ca.number_format != cb.number_format:
                    diffs.append(CellDiff(name, _coord(r, c), "number_format",
                                          str(ca.number_format), str(cb.number_format)))
                if _font_sig(ca.font) != _font_sig(cb.font):
                    diffs.append(CellDiff(name, _coord(r, c), "font",
                                          _font_repr(ca.font), _font_repr(cb.font)))
                if _fill_sig(ca.fill) != _fill_sig(cb.fill):
                    diffs.append(CellDiff(name, _coord(r, c), "fill",
                                          _fill_repr(ca.fill), _fill_repr(cb.fill)))
                if _align_sig(ca.alignment) != _align_sig(cb.alignment):
                    diffs.append(CellDiff(name, _coord(r, c), "alignment",
                                          _align_repr(ca.alignment), _align_repr(cb.alignment)))
                if _border_sig(ca.border) != _border_sig(cb.border):
                    diffs.append(CellDiff(name, _coord(r, c), "border",
                                          _border_repr(ca.border), _border_repr(cb.border)))

    # --- layout(可選)---
    if cfg.COMPARE_LAYOUT:
        _layout_diffs(wsa, wsb, name, diffs)

    diffs.sort(key=lambda d: _sortkey(d.ref))
    return SheetDiff(name, ar, ac, br, bc, diffs)


# --------------------------------------------------------------------------- #
# 對外 API
# --------------------------------------------------------------------------- #
def compare_workbooks(path_a, path_b, cfg=config, progress=None, cancelled=None) -> WorkbookDiff:
    path_a = converter.ensure_xlsx(path_a)
    path_b = converter.ensure_xlsx(path_b)
    wba = load_workbook(str(path_a), data_only=False, read_only=False, keep_links=False)
    wbb = load_workbook(str(path_b), data_only=False, read_only=False, keep_links=False)
    try:
        names_a, names_b = wba.sheetnames, wbb.sheetnames
        seta, setb = set(names_a), set(names_b)
        common = [n for n in names_a if n in setb]
        only_a = [n for n in names_a if n not in setb]
        only_b = [n for n in names_b if n not in seta]
        sheets = []
        for k, name in enumerate(common):
            if cancelled is not None and cancelled():
                break
            sheets.append(_compare_sheet(wba[name], wbb[name], name, cfg))
            if progress is not None:
                progress(k + 1, len(common))
        return WorkbookDiff(common, only_a, only_b, sheets)
    finally:
        wba.close()
        wbb.close()


def read_grid(path, sheet, max_rows=None, max_cols=None):
    """讀一個 sheet 嘅值做 2D(俾 GUI 並排格線)。回傳 (rows, n_rows, n_cols)。"""
    path = converter.ensure_xlsx(path)
    wb = load_workbook(str(path), data_only=False, read_only=True)
    try:
        if sheet not in wb.sheetnames:
            return [], 0, 0
        ws = wb[sheet]
        mr, mc = ws.max_row or 0, ws.max_column or 0
        if max_rows:
            mr = min(mr, max_rows)
        if max_cols:
            mc = min(mc, max_cols)
        if mr == 0 or mc == 0:
            return [], 0, 0
        rows = list(ws.iter_rows(min_row=1, max_row=mr, min_col=1, max_col=mc, values_only=True))
        return rows, mr, mc
    finally:
        wb.close()


def _ref_to_rc(ref):
    m = re.match(r"^([A-Z]+)(\d+)$", ref)
    if not m:
        return None
    return (int(m.group(2)), column_index_from_string(m.group(1)))


def highlight_map(sheet_diff: SheetDiff) -> dict:
    """{(row, col): 'value'|'added'|'removed'|'format'} 俾格線上色。"""
    m: dict = {}
    for d in sheet_diff.diffs:
        rc = _ref_to_rc(d.ref)
        if rc is None:
            continue
        if d.kind == "value":
            cat = "added" if d.a == "(empty)" else ("removed" if d.b == "(empty)" else "value")
        else:
            cat = "format"
        if rc in m and m[rc] in ("value", "added", "removed"):
            continue      # 值差異優先於格式差異
        m[rc] = cat
    return m


# --------------------------------------------------------------------------- #
# 匯出 xlsx 報告
# --------------------------------------------------------------------------- #
def export_report_xlsx(items, out_path, cfg=config, progress=None, cancelled=None):
    """items: list of dict{label, a, b, a_disp, b_disp}。出一份 xlsx:Summary + Differences。"""
    from openpyxl.styles import Alignment, Font, PatternFill

    rep = Workbook()
    summary = rep.active
    summary.title = "Summary"
    summary.append(["Workbook", "A", "B", "Common sheets", "Only in A", "Only in B", "Differences"])

    diff_ws = rep.create_sheet("Differences")
    diff_ws.append(["Workbook", "Sheet", "Cell / scope", "Type", "A", "B"])

    total = len(items)
    for k, it in enumerate(items):
        if cancelled is not None and cancelled():
            break
        wd = compare_workbooks(it["a"], it["b"], cfg)
        summary.append([
            it["label"],
            str(it.get("a_disp", it["a"])),
            str(it.get("b_disp", it["b"])),
            len(wd.common),
            ", ".join(wd.only_a),
            ", ".join(wd.only_b),
            wd.total_diffs,
        ])
        for sd in wd.sheets:
            for d in sd.diffs:
                diff_ws.append([it["label"], d.sheet, d.ref, d.kind, d.a, d.b])
        if progress is not None:
            progress(k + 1, total)

    # 簡單美化
    head_font = Font(bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="374151")
    for ws in (summary, diff_ws):
        for cell in ws[1]:
            cell.font = head_font
            cell.fill = head_fill
            cell.alignment = Alignment(vertical="center")
        ws.freeze_panes = "A2"
        # 粗略欄闊
        widths = {"Summary": [34, 40, 40, 14, 24, 24, 12],
                  "Differences": [34, 20, 14, 16, 34, 34]}[ws.title]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w

    rep.save(str(out_path))
    return out_path
