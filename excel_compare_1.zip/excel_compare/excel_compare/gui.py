"""PySide6 GUI:揀兩個資料夾 → 配對 Excel 檔 → 逐個共同 worksheet 睇差異。

因為 Excel 唔似 PDF 咁 render 成圖,呢個版本以:
  • 全部差異表(# / Sheet / Cell / Type / A / B),click 一行跳去
  • 並排格線(A | B),唔同嘅 cell 上色(值=黃、加=綠、減=紅、淨格式=藍),scroll 同步
為主。多出嚟嘅 worksheet 會喺摘要度列出但唔比。
"""
from __future__ import annotations

import sys
from pathlib import Path

from openpyxl.utils import get_column_letter

from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QColor, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressDialog,
    QPushButton,
    QRadioButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from . import comparer, config
from .matcher import MatchPair, match_files, similarity
from .scanner import XlFile, scan_excels


# --------------------------------------------------------------------------- #
class ScanWorker(QThread):
    done = Signal(object, object, object)
    failed = Signal(str)

    def __init__(self, root_a, root_b, threshold):
        super().__init__()
        self.root_a, self.root_b, self.threshold = root_a, root_b, threshold

    def run(self):
        try:
            fa = scan_excels(self.root_a)
            fb = scan_excels(self.root_b)
            pairs, ua, ub = match_files(fa, fb, self.threshold)
            self.done.emit(pairs, ua, ub)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class CompareWorker(QThread):
    progress = Signal(int, int)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, pair: MatchPair, settings):
        super().__init__()
        self.pair = pair
        self.settings = settings

    def run(self):
        try:
            wd = comparer.compare_workbooks(
                self.pair.a.path, self.pair.b.path, cfg=self.settings,
                progress=lambda d, t: self.progress.emit(d, t),
                cancelled=lambda: self.isInterruptionRequested(),
            )
            if self.isInterruptionRequested():
                return
            self.done.emit(wd)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class ExportWorker(QThread):
    progress = Signal(int, int)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, items, out, settings):
        super().__init__()
        self.items, self.out, self.settings = items, out, settings

    def run(self):
        try:
            comparer.export_report_xlsx(
                self.items, self.out, cfg=self.settings,
                progress=lambda d, t: self.progress.emit(d, t),
                cancelled=lambda: self.isInterruptionRequested(),
            )
            if self.isInterruptionRequested():
                return
            self.done.emit(str(self.out))
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class ExportDialog(QDialog):
    def __init__(self, parent=None, has_current=True, n_pairs=1):
        super().__init__(parent)
        self.setWindowTitle("Export report")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("<b>What to export</b>"))
        self.rb_current = QRadioButton("This pair")
        self.rb_all = QRadioButton(f"All matched pairs ({n_pairs})")
        self.rb_current.setChecked(has_current)
        self.rb_all.setChecked(not has_current)
        self.rb_current.setEnabled(has_current)
        grp = QButtonGroup(self)
        grp.addButton(self.rb_current)
        grp.addButton(self.rb_all)
        lay.addWidget(self.rb_current)
        lay.addWidget(self.rb_all)
        lay.addWidget(QLabel("Output: an Excel (.xlsx) report — Summary + Differences."))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def scope(self):
        return "current" if self.rb_current.isChecked() else "all"


# --------------------------------------------------------------------------- #
class MainWindow(QMainWindow):
    def __init__(self, prefill_a="", prefill_b=""):
        super().__init__()
        self.setWindowTitle("Excel Compare — Workbook Diff")
        self.resize(1500, 920)

        self.pairs: list[MatchPair] = []
        self.unmatched_a: list[XlFile] = []
        self.unmatched_b: list[XlFile] = []
        self.current_pair: MatchPair | None = None
        self.current_diff: comparer.WorkbookDiff | None = None
        self.settings = config.Settings()

        self._scan_worker: ScanWorker | None = None
        self._cmp_worker: CompareWorker | None = None
        self._exp_worker: ExportWorker | None = None
        self._progress: QProgressDialog | None = None
        self._grid_sync = False

        self._build_ui()
        if prefill_a:
            self.le_a.setText(prefill_a)
        if prefill_b:
            self.le_b.setText(prefill_b)

    # ---- UI ----------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.addWidget(self._build_top())
        split = QSplitter(Qt.Horizontal)
        split.addWidget(self._build_left())
        split.addWidget(self._build_right())
        split.setSizes([330, 1170])
        split.setStretchFactor(1, 1)
        root.addWidget(split, 1)
        self.statusBar().showMessage("Pick two folders, then click 'Scan & Match'.")
        QShortcut(QKeySequence("Ctrl+E"), self, self._export)

    def _build_top(self) -> QWidget:
        w = QFrame()
        w.setFrameShape(QFrame.StyledPanel)
        v = QVBoxLayout(w)

        self.le_a = QLineEdit(); self.le_a.setPlaceholderText("Folder A path")
        ba = QPushButton("Browse…"); ba.clicked.connect(lambda: self._browse(self.le_a))
        ra = QHBoxLayout(); ra.addWidget(QLabel("Folder A")); ra.addWidget(self.le_a, 1); ra.addWidget(ba)
        v.addLayout(ra)

        self.le_b = QLineEdit(); self.le_b.setPlaceholderText("Folder B path")
        bb = QPushButton("Browse…"); bb.clicked.connect(lambda: self._browse(self.le_b))
        rb = QHBoxLayout(); rb.addWidget(QLabel("Folder B")); rb.addWidget(self.le_b, 1); rb.addWidget(bb)
        v.addLayout(rb)

        row = QHBoxLayout()
        row.addWidget(QLabel("Name match"))
        self.spin_thr = QSpinBox(); self.spin_thr.setRange(0, 100); self.spin_thr.setValue(config.MATCH_THRESHOLD)
        self.spin_thr.setSuffix(" %")
        self.spin_thr.setToolTip("Minimum filename similarity to auto-pair. Applies on next scan.")
        row.addWidget(self.spin_thr)
        self.cb_fmt = QCheckBox("Compare formatting"); self.cb_fmt.setChecked(config.COMPARE_FORMATTING)
        self.cb_fmt.setToolTip("number format / font / fill / alignment / border")
        self.cb_lay = QCheckBox("Compare layout"); self.cb_lay.setChecked(config.COMPARE_LAYOUT)
        self.cb_lay.setToolTip("merged cells / column width / row height")
        self.cb_fmt.toggled.connect(self._on_opts_changed)
        self.cb_lay.toggled.connect(self._on_opts_changed)
        row.addWidget(self.cb_fmt)
        row.addWidget(self.cb_lay)
        self.btn_scan = QPushButton("Scan & Match"); self.btn_scan.clicked.connect(self._start_scan)
        row.addWidget(self.btn_scan)
        row.addStretch(1)
        v.addLayout(row)
        return w

    def _build_left(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self._h("Matched (similarity)"))
        self.lst_pairs = QListWidget(); self.lst_pairs.currentItemChanged.connect(self._on_pair_selected)
        v.addWidget(self.lst_pairs, 3)
        bu = QPushButton("Unpair selected ↓"); bu.clicked.connect(self._unpair)
        v.addWidget(bu)
        v.addWidget(self._h("Unmatched A"))
        self.lst_ua = QListWidget(); v.addWidget(self.lst_ua, 2)
        v.addWidget(self._h("Unmatched B"))
        self.lst_ub = QListWidget(); v.addWidget(self.lst_ub, 2)
        bp = QPushButton("↑ Pair selected A + B"); bp.clicked.connect(self._manual_pair)
        v.addWidget(bp)
        return w

    def _build_right(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)

        self.lbl_pair = QLabel("—")
        self.lbl_pair.setStyleSheet("font-weight:bold;font-size:14px")
        self.lbl_pair.setWordWrap(True)
        v.addWidget(self.lbl_pair)

        self.lbl_sheets = QLabel("")
        self.lbl_sheets.setWordWrap(True)
        v.addWidget(self.lbl_sheets)

        row = QHBoxLayout()
        row.addWidget(QLabel("Sheet:"))
        self.combo_sheet = QComboBox(); self.combo_sheet.currentIndexChanged.connect(self._on_sheet_changed)
        row.addWidget(self.combo_sheet, 1)
        self.lbl_grid = QLabel(""); self.lbl_grid.setStyleSheet("color:#6b7280")
        row.addWidget(self.lbl_grid)
        row.addStretch(1)
        self.btn_export = QPushButton("Export report…"); self.btn_export.clicked.connect(self._export)
        row.addWidget(self.btn_export)
        v.addLayout(row)

        vsplit = QSplitter(Qt.Vertical)

        # grid (A | B)
        grids = QWidget(); gl = QVBoxLayout(grids); gl.setContentsMargins(0, 0, 0, 0)
        legend = QLabel(
            f'<span style="background:{config.COL_VALUE}">&nbsp;value&nbsp;</span>&nbsp;'
            f'<span style="background:{config.COL_ADDED}">&nbsp;added (B)&nbsp;</span>&nbsp;'
            f'<span style="background:{config.COL_REMOVED}">&nbsp;removed (A)&nbsp;</span>&nbsp;'
            f'<span style="background:{config.COL_FORMAT}">&nbsp;format only&nbsp;</span>'
        )
        gl.addWidget(legend)
        gsplit = QSplitter(Qt.Horizontal)
        self.grid_a = self._make_grid("A · original", "#b91c1c")
        self.grid_b = self._make_grid("B · compare", "#15803d")
        gsplit.addWidget(self.grid_a["box"]); gsplit.addWidget(self.grid_b["box"])
        gsplit.setSizes([600, 600])
        gl.addWidget(gsplit)
        self._link_grids(self.grid_a["table"], self.grid_b["table"])
        vsplit.addWidget(grids)

        # difference table
        bottom = QWidget(); bvl = QVBoxLayout(bottom); bvl.setContentsMargins(0, 0, 0, 0)
        bvl.addWidget(QLabel("Differences — click a row to jump"))
        self.tbl = QTableWidget(0, 6)
        self.tbl.setHorizontalHeaderLabels(["#", "Sheet", "Cell / scope", "Type", "A", "B"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        hdr = self.tbl.horizontalHeader()
        for i in (0, 1, 2, 3):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(4, QHeaderView.Stretch)
        hdr.setSectionResizeMode(5, QHeaderView.Stretch)
        self.tbl.cellClicked.connect(self._on_diff_row)
        bvl.addWidget(self.tbl)
        vsplit.addWidget(bottom)
        vsplit.setSizes([560, 300])
        v.addWidget(vsplit, 1)
        return w

    def _make_grid(self, label, color):
        box = QWidget(); lay = QVBoxLayout(box); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(2)
        lbl = QLabel(label); lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet(f"color:white;background:{color};padding:3px;font-weight:bold;border-radius:2px")
        table = QTableWidget(0, 0)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        lay.addWidget(lbl); lay.addWidget(table)
        return {"box": box, "table": table, "label": lbl}

    def _link_grids(self, ta, tb):
        def mk(src, dst):
            def handler(_v=None):
                if self._grid_sync:
                    return
                self._grid_sync = True
                dst.verticalScrollBar().setValue(src.verticalScrollBar().value())
                dst.horizontalScrollBar().setValue(src.horizontalScrollBar().value())
                self._grid_sync = False
            return handler
        ta.verticalScrollBar().valueChanged.connect(mk(ta, tb))
        ta.horizontalScrollBar().valueChanged.connect(mk(ta, tb))
        tb.verticalScrollBar().valueChanged.connect(mk(tb, ta))
        tb.horizontalScrollBar().valueChanged.connect(mk(tb, ta))

    @staticmethod
    def _h(text):
        lbl = QLabel(text); lbl.setStyleSheet("font-weight:bold;padding:2px")
        return lbl

    # ---- scan / match ------------------------------------------------------
    def _browse(self, le):
        d = QFileDialog.getExistingDirectory(self, "Choose folder", le.text() or str(Path.home()))
        if d:
            le.setText(d)

    def _start_scan(self):
        a, b = self.le_a.text().strip(), self.le_b.text().strip()
        if not a or not b:
            QMessageBox.warning(self, "Missing folder", "Both folder paths are required.")
            return
        if not Path(a).is_dir() or not Path(b).is_dir():
            QMessageBox.warning(self, "Invalid path", "One of the paths is not a valid folder.")
            return
        self.btn_scan.setEnabled(False)
        self.settings.MATCH_THRESHOLD = self.spin_thr.value()
        self.statusBar().showMessage("Scanning…")
        self._scan_worker = ScanWorker(a, b, self.spin_thr.value())
        self._scan_worker.done.connect(self._on_scan_done)
        self._scan_worker.failed.connect(self._on_scan_failed)
        self._scan_worker.start()

    def _on_scan_done(self, pairs, ua, ub):
        self.btn_scan.setEnabled(True)
        self.pairs, self.unmatched_a, self.unmatched_b = list(pairs), list(ua), list(ub)
        self._refresh_lists()
        self.statusBar().showMessage(f"Matched {len(self.pairs)} pair(s); unmatched A={len(ua)}, B={len(ub)}.")

    def _on_scan_failed(self, msg):
        self.btn_scan.setEnabled(True)
        QMessageBox.critical(self, "Scan failed", msg)
        self.statusBar().showMessage("Scan failed.")

    def _refresh_lists(self):
        self.lst_pairs.clear()
        for p in self.pairs:
            it = QListWidgetItem(f"{p.score:5.1f}%   {p.a.name}  ⇄  {p.b.name}")
            it.setToolTip(f"A: {p.a.rel}\nB: {p.b.rel}")
            it.setData(Qt.UserRole, p)
            self.lst_pairs.addItem(it)
        self.lst_ua.clear()
        for f in self.unmatched_a:
            it = QListWidgetItem(f.name); it.setToolTip(str(f.rel)); it.setData(Qt.UserRole, f)
            self.lst_ua.addItem(it)
        self.lst_ub.clear()
        for f in self.unmatched_b:
            it = QListWidgetItem(f.name); it.setToolTip(str(f.rel)); it.setData(Qt.UserRole, f)
            self.lst_ub.addItem(it)

    def _manual_pair(self):
        ia, ib = self.lst_ua.currentItem(), self.lst_ub.currentItem()
        if not ia or not ib:
            QMessageBox.information(self, "Manual pair", "Select one item in Unmatched A and one in Unmatched B.")
            return
        fa, fb = ia.data(Qt.UserRole), ib.data(Qt.UserRole)
        self.pairs.append(MatchPair(fa, fb, similarity(fa.name, fb.name)))
        self.pairs.sort(key=lambda p: p.score, reverse=True)
        self.unmatched_a = [f for f in self.unmatched_a if f is not fa]
        self.unmatched_b = [f for f in self.unmatched_b if f is not fb]
        self._refresh_lists()

    def _unpair(self):
        it = self.lst_pairs.currentItem()
        if not it:
            return
        pair = it.data(Qt.UserRole)
        self.pairs = [p for p in self.pairs if p is not pair]
        self.unmatched_a.append(pair.a); self.unmatched_b.append(pair.b)
        self.unmatched_a.sort(key=lambda f: str(f.rel).lower())
        self.unmatched_b.sort(key=lambda f: str(f.rel).lower())
        if self.current_pair is pair:
            self.current_pair = None
            self.current_diff = None
            self.lbl_pair.setText("—"); self.lbl_sheets.setText("")
            self._clear_all()
        self._refresh_lists()

    # ---- compare a pair ----------------------------------------------------
    def _on_pair_selected(self, cur, _prev=None):
        if cur is None:
            return
        self._load_pair(cur.data(Qt.UserRole))

    def _load_pair(self, pair: MatchPair):
        self.current_pair = pair
        self.current_diff = None
        self.lbl_pair.setText(f"A:  {pair.a.rel}\nB:  {pair.b.rel}")
        self.lbl_sheets.setText("Comparing…")
        self._clear_all()
        self._start_compare()

    def _start_compare(self):
        if self.current_pair is None:
            return
        if self._cmp_worker is not None and self._cmp_worker.isRunning():
            self._cmp_worker.requestInterruption()
            self._cmp_worker.wait(3000)
        self.settings.COMPARE_FORMATTING = self.cb_fmt.isChecked()
        self.settings.COMPARE_LAYOUT = self.cb_lay.isChecked()
        self.statusBar().showMessage("Comparing worksheets…")
        self._cmp_worker = CompareWorker(self.current_pair, self.settings)
        self._cmp_worker.progress.connect(lambda d, t: self.statusBar().showMessage(f"Comparing sheet {d}/{t}…"))
        self._cmp_worker.done.connect(self._on_compare_done)
        self._cmp_worker.failed.connect(self._on_compare_failed)
        self._cmp_worker.start()

    def _on_compare_failed(self, msg):
        self.lbl_sheets.setText("")
        QMessageBox.critical(self, "Comparison failed", msg)
        self.statusBar().showMessage("Comparison failed.")

    def _on_compare_done(self, wd: comparer.WorkbookDiff):
        self.current_diff = wd
        only_a = ", ".join(wd.only_a) or "—"
        only_b = ", ".join(wd.only_b) or "—"
        self.lbl_sheets.setText(
            f"Common sheets: {len(wd.common)}   |   Only in A: {only_a}   |   Only in B: {only_b}"
            f"   |   Total differences: {wd.total_diffs}"
        )
        # sheet combo
        self.combo_sheet.blockSignals(True)
        self.combo_sheet.clear()
        self.combo_sheet.addItem(f"All sheets ({wd.total_diffs})", None)
        for sd in wd.sheets:
            self.combo_sheet.addItem(f"{sd.name}  ({len(sd.diffs)})", sd.name)
        self.combo_sheet.setCurrentIndex(0)
        self.combo_sheet.blockSignals(False)

        self._fill_table(None)
        # 自動揀第一個有差異嘅 sheet 去顯示格線
        first = next((sd.name for sd in wd.sheets if sd.diffs), wd.sheets[0].name if wd.sheets else None)
        if first:
            idx = self.combo_sheet.findData(first)
            if idx >= 0:
                self.combo_sheet.setCurrentIndex(idx)   # 觸發 grid + table filter
        else:
            self._clear_grids()
        self.statusBar().showMessage(f"Done — {wd.total_diffs} difference(s) across {len(wd.common)} common sheet(s).")

    # ---- sheet view --------------------------------------------------------
    def _on_sheet_changed(self, _idx):
        name = self.combo_sheet.currentData()
        self._fill_table(name)
        if name is None:
            self._clear_grids()
            self.lbl_grid.setText("Pick a sheet to see the grid")
        else:
            self._load_grid(name)

    def _sheet_diff(self, name):
        if self.current_diff is None:
            return None
        for sd in self.current_diff.sheets:
            if sd.name == name:
                return sd
        return None

    def _fill_table(self, sheet_name):
        self.tbl.setRowCount(0)
        if self.current_diff is None:
            return
        rid = 0
        for sd in self.current_diff.sheets:
            if sheet_name is not None and sd.name != sheet_name:
                continue
            for d in sd.diffs:
                rid += 1
                self._add_row(rid, d)
        if self.tbl.rowCount() == 0:
            r = self.tbl.rowCount(); self.tbl.insertRow(r)
            it = QTableWidgetItem("(no differences)"); it.setForeground(QColor("#9aa0aa"))
            for c in range(6):
                self.tbl.setItem(r, c, QTableWidgetItem("") if c else it)

    def _add_row(self, rid, d: comparer.CellDiff):
        r = self.tbl.rowCount(); self.tbl.insertRow(r)
        vals = [str(rid), d.sheet, d.ref, d.kind, d.a, d.b]
        for c, val in enumerate(vals):
            it = QTableWidgetItem(val)
            if c == 0:
                it.setData(Qt.UserRole, (d.sheet, d.ref))
            self.tbl.setItem(r, c, it)

    def _load_grid(self, name):
        sd = self._sheet_diff(name)
        try:
            rows_a, ar, ac = comparer.read_grid(self.current_pair.a.path, name,
                                                self.settings.GRID_MAX_ROWS, self.settings.GRID_MAX_COLS)
            rows_b, br, bc = comparer.read_grid(self.current_pair.b.path, name,
                                                self.settings.GRID_MAX_ROWS, self.settings.GRID_MAX_COLS)
        except Exception as exc:  # noqa: BLE001
            self._clear_grids()
            self.lbl_grid.setText(f"grid error: {exc}")
            return
        nr, nc = max(ar, br), max(ac, bc)
        self._populate(self.grid_a["table"], rows_a, nr, nc)
        self._populate(self.grid_b["table"], rows_b, nr, nc)
        if sd is not None:
            self._apply_highlight(comparer.highlight_map(sd), nr, nc)
        capped = (nr >= self.settings.GRID_MAX_ROWS or nc >= self.settings.GRID_MAX_COLS)
        self.lbl_grid.setText(f"{name}: {nr}×{nc}" + ("  (capped)" if capped else ""))

    @staticmethod
    def _populate(table, rows, nr, nc):
        table.clear()
        table.setRowCount(nr)
        table.setColumnCount(nc)
        table.setHorizontalHeaderLabels([get_column_letter(c + 1) for c in range(nc)])
        table.setVerticalHeaderLabels([str(r + 1) for r in range(nr)])
        for r in range(nr):
            rowvals = rows[r] if r < len(rows) else ()
            for c in range(nc):
                v = rowvals[c] if c < len(rowvals) else None
                table.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))

    def _apply_highlight(self, hlmap, nr, nc):
        colors = {"value": self.settings.COL_VALUE, "format": self.settings.COL_FORMAT,
                  "added": self.settings.COL_ADDED, "removed": self.settings.COL_REMOVED}
        for (row, col), cat in hlmap.items():
            if row > nr or col > nc:
                continue
            color = QColor(colors.get(cat, self.settings.COL_VALUE))
            for grid in (self.grid_a["table"], self.grid_b["table"]):
                it = grid.item(row - 1, col - 1)
                if it:
                    it.setBackground(color)

    def _on_diff_row(self, row, _col):
        it = self.tbl.item(row, 0)
        data = it.data(Qt.UserRole) if it else None
        if not data:
            return
        sheet, ref = data
        # 切去嗰個 sheet(會 load grid)
        if self.combo_sheet.currentData() != sheet:
            idx = self.combo_sheet.findData(sheet)
            if idx >= 0:
                self.combo_sheet.setCurrentIndex(idx)
        rc = comparer._ref_to_rc(ref)
        if rc is None:
            return
        r, c = rc[0] - 1, rc[1] - 1
        for grid in (self.grid_a["table"], self.grid_b["table"]):
            if r < grid.rowCount() and c < grid.columnCount():
                grid.setCurrentCell(r, c)
                grid.scrollToItem(grid.item(r, c), QAbstractItemView.PositionAtCenter)

    def _clear_grids(self):
        for g in (self.grid_a, self.grid_b):
            g["table"].clear(); g["table"].setRowCount(0); g["table"].setColumnCount(0)

    def _clear_all(self):
        self.combo_sheet.blockSignals(True); self.combo_sheet.clear(); self.combo_sheet.blockSignals(False)
        self.tbl.setRowCount(0)
        self._clear_grids()
        self.lbl_grid.setText("")

    def _on_opts_changed(self, _checked=False):
        # 改咗比對範圍 → 重新比當前一對
        if self.current_pair is not None:
            self._start_compare()

    # ---- export ------------------------------------------------------------
    def _export(self):
        if not self.pairs:
            QMessageBox.information(self, "Export report", "Scan & match first — there's nothing to export.")
            return
        dlg = ExportDialog(self, has_current=self.current_pair is not None, n_pairs=len(self.pairs))
        if dlg.exec() != QDialog.Accepted:
            return
        if dlg.scope() == "current":
            if self.current_pair is None:
                return
            pairs = [self.current_pair]
        else:
            pairs = self.pairs
        items = [{"label": f"{p.a.name}  vs  {p.b.name}", "a": p.a.path, "b": p.b.path,
                  "a_disp": str(p.a.rel), "b_disp": str(p.b.rel)} for p in pairs]
        default = f"{pairs[0].a.stem}_diff.xlsx" if len(pairs) == 1 else "excel_diff_report.xlsx"
        out, _ = QFileDialog.getSaveFileName(self, "Save report", default, "Excel (*.xlsx)")
        if not out:
            return
        self.settings.COMPARE_FORMATTING = self.cb_fmt.isChecked()
        self.settings.COMPARE_LAYOUT = self.cb_lay.isChecked()
        self._progress = QProgressDialog("Exporting…", "Cancel", 0, len(items), self)
        self._progress.setWindowTitle("Export"); self._progress.setWindowModality(Qt.WindowModal)
        self._progress.setMinimumDuration(0)
        self._exp_worker = ExportWorker(items, out, self.settings)
        self._exp_worker.progress.connect(self._on_exp_progress)
        self._exp_worker.done.connect(self._on_exp_done)
        self._exp_worker.failed.connect(self._on_exp_failed)
        self._progress.canceled.connect(self._exp_worker.requestInterruption)
        self._exp_worker.start()

    def _on_exp_progress(self, d, t):
        if self._progress:
            self._progress.setMaximum(t); self._progress.setValue(d)

    def _on_exp_done(self, msg):
        if self._progress:
            self._progress.reset(); self._progress = None
        self.statusBar().showMessage(f"Export complete — {msg}")
        QMessageBox.information(self, "Export complete", f"Saved:\n{msg}")

    def _on_exp_failed(self, msg):
        if self._progress:
            self._progress.reset(); self._progress = None
        QMessageBox.critical(self, "Export failed", msg)


# --------------------------------------------------------------------------- #
def main():
    app = QApplication(sys.argv)
    a = sys.argv[1] if len(sys.argv) > 1 else ""
    b = sys.argv[2] if len(sys.argv) > 2 else ""
    win = MainWindow(prefill_a=a, prefill_b=b)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
