"""用檔名相似度配對兩個資料夾嘅 Excel 檔(rapidfuzz + 匈牙利演算法)。"""
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
from rapidfuzz import fuzz, process

from . import config
from .scanner import XlFile

_SEP = re.compile(r"[_\-.]+")
_NOISE = re.compile(
    r"\b(v\d+|ver\d*|rev\d*|final|draft|copy|"
    r"\d{4}[-_]?\d{2}[-_]?\d{2}|\d{6,8})\b"
)
_WS = re.compile(r"\s+")


def normalize(name: str) -> str:
    s = name.lower()
    for ext in config.SCAN_EXTS:
        if s.endswith(ext):
            s = s[: -len(ext)]
            break
    s = _SEP.sub(" ", s)
    s = _NOISE.sub(" ", s)
    s = _WS.sub(" ", s).strip()
    return s or name.lower()


def similarity(a: str, b: str) -> float:
    return float(fuzz.WRatio(normalize(a), normalize(b)))


@dataclass
class MatchPair:
    a: XlFile
    b: XlFile
    score: float


def match_files(files_a, files_b, threshold=config.MATCH_THRESHOLD):
    from scipy.optimize import linear_sum_assignment

    if not files_a or not files_b:
        return [], list(files_a), list(files_b)

    names_a = [normalize(f.name) for f in files_a]
    names_b = [normalize(f.name) for f in files_b]
    sim = process.cdist(names_a, names_b, scorer=fuzz.WRatio, dtype=np.float32, workers=-1)
    row, col = linear_sum_assignment(sim, maximize=True)

    pairs, used_a, used_b = [], set(), set()
    for i, j in zip(row, col):
        if sim[i, j] >= threshold:
            pairs.append(MatchPair(files_a[i], files_b[j], float(sim[i, j])))
            used_a.add(int(i)); used_b.add(int(j))
    pairs.sort(key=lambda p: p.score, reverse=True)
    unmatched_a = [f for k, f in enumerate(files_a) if k not in used_a]
    unmatched_b = [f for k, f in enumerate(files_b) if k not in used_b]
    return pairs, unmatched_a, unmatched_b


def best_candidates(target, others, k=5):
    scored = [(o, similarity(target.name, o.name)) for o in others]
    scored.sort(key=lambda t: t[1], reverse=True)
    return scored[:k]
