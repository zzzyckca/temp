# ==========================================================================
# CNB MMR(LOB) report generator  --  PHASE 3
# All engine logic lives in cnb_common_phase3.py. This script is just a
# self-contained cfg dict + import + the two calls.
# Run: python CNB_mmrlob_phase3.py
# ==========================================================================

cfg = {
    # ---- per-report identity (column in config.xlsx 'ou_list' / results subfolder / template) ----
    "report_column":  "MMR(LOB)",
    "root_folder":    "MMR(LOB)",
    "template_file":  "MMR(LOB)-template.xlsx",

    # ---- paths: full hard-coded UNC, raw strings ----
    "config_path":    r"\\maple.fg.rbc.com\data\Toronto\wrkgrp\wrkgrp11\Shared Services Reporting Centre\Individual Folders\Leo\CNB Project\templates\config.xlsx",
    "template_dir":   r"\\maple.fg.rbc.com\data\Toronto\wrkgrp\wrkgrp11\Shared Services Reporting Centre\Individual Folders\Leo\CNB Project\templates",
    "report_address": r"\\maple.fg.rbc.com\data\Toronto\wrkgrp\wrkgrp11\Shared Services Reporting Centre\Individual Folders\Leo\CNB Project\results",
    "ou_sheet":       "ou_list",     # sheet inside config.xlsx holding the OU codes (one column per report)
    "temp_folder":    r"C:\cnb_project",
    "log_folder":     r"C:\temp1",

    # ---- TM1 endpoint ----
    "tm1_server":     "SE140939.fg.rbc.com",
    "tm1_port":       "13111",
    "tm1_namespace":  "maple",

    # ---- per-script tunables ----
    "num_processes":  8,
    "prefetch_depth": 2,
    "target_lvl":     4,
    "sample_n":       None,     # None = full run; set e.g. 15 to render only the first 15 OUs.

    # ---- robocopy whole-command retry ----
    "robocopy_max_tries":  3,
    "robocopy_retry_wait": 2,

    # ---- sheets NOT exported to PDF ----
    "remove_list": ['EPM_ControlSheet', 'Cognos_Office_Connection_Cache', 'Title',
                    'EPM (Data)', 'List', 'Hierarchy', 'EPM_info'],

    # ---- ad-hoc period override ----
    #   Normal run: leave all three None (EPM_INFO/template TODAY() formulas drive the period).
    #   Ad-hoc run: fill ALL THREE as strings, e.g.
    #     "adhoc": {"calendar_year": "2026", "fiscal_year": "2026", "reporting_month": "06"}
    #   These values are used for THIS run ONLY: they are written into EPM_INFO A2/B2 and the
    #   template's EPM_ControlSheet E28/E29/E30 in-memory, but NOTHING is saved back to disk.
    #   The config.xlsx and template files keep their TODAY() formulas, so the NEXT run does NOT
    #   remember this override -- it reverts to the automatic (run-date) period unless you set it again.
    "adhoc": {"calendar_year": None, "fiscal_year": None, "reporting_month": None},
}

from cnb_common_phase3 import *

if __name__ == "__main__":
    mdx, acct_map_dict, reporting_period, pivot_index, ou_codes = config_mdx(cfg)
    run_report(cfg, mdx, acct_map_dict, reporting_period, pivot_index, ou_codes)
